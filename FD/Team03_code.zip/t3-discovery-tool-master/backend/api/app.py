from flask import Flask
from flask_cors import CORS

from api.endpoints.goal_endpoints import GoalsDashBoardEndpoint
from .config import app_configs
from .extensions import api, db, ma, bcrypt, jwt
from .endpoints import Ping, Login, Logout, UserListEndpoint, UserEndpoint, IdeasEndpoint, IdeaEndpoint, GoalEndpoint, GoalsEndpoint, WorkProgress

def create_app(config_name):
    app = Flask(__name__)
    app.config.from_object(app_configs[config_name])

    db.init_app(app)
    CORS(app, supports_credentials=True)
    ma.init_app(app)
    bcrypt.init_app(app)
    jwt.init_app(app)

    api.init_app(app, prefix='/api')
    api.title = 'Ideas API'
    api.authorizations = {
        'apikey': {
            'type': 'apiKey',
            'in': 'header',
            'name': 'Authorization'
        }
    }

    api.add_resource(Ping, '/ping', endpoint='ping')
    api.add_resource(Login, '/auth/login', endpoint='login')
    api.add_resource(Logout, '/auth/logout', endpoint='logout')
    api.add_resource(UserListEndpoint, '/users', endpoint='users')
    api.add_resource(UserEndpoint, '/users/<string:username>', endpoint='user')
    api.add_resource(IdeasEndpoint, '/ideas/', endpoint='ideas')
    api.add_resource(IdeaEndpoint, '/ideas/<string:idea_id>', endpoint='idea')
    api.add_resource(GoalsEndpoint, '/goals', endpoint='goals')

    api.add_resource(GoalEndpoint, '/goal/<string:goal_id>', endpoint='goal')
    api.add_resource(WorkProgress, '/workprogress', endpoint='goals_dashboard')

    return app
