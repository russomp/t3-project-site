from datetime import datetime

from marshmallow_mongoengine import ModelSchema

from ..extensions import db


class User(db.Document):
  username = db.StringField(required=True, unique=True, max_length=32)
  password = db.StringField(required=True, max_length=80)
  first_name = db.StringField(max_length=50)
  last_name = db.StringField(max_length=50)
  city = db.StringField(max_length=50)
  state = db.StringField(max_length=50)
  country = db.StringField(max_length=10)
  role = db.StringField(required=True, default="writer", choices=["writer", "admin", "superadmin"])
  is_active = db.BooleanField(default=True)
  created_at = db.DateTimeField(default=datetime.today())
  updated_at = db.DateTimeField(default=datetime.today())

  meta = {'collection': 'users'}


class UserSchema(ModelSchema):
    class Meta:
        model = User


hidden_fields = ("id", "password")
user_schema = UserSchema(load_only=hidden_fields)
user_list_schema = UserSchema(load_only=hidden_fields, many=True)
