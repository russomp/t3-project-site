from datetime import datetime

from marshmallow_mongoengine import ModelSchema

from ..extensions import db
from .goal import Goal


class Details(db.EmbeddedDocument):
    url = db.StringField(default=None)
    description = db.StringField(default=None, max_length=80)
    network = db.StringField(default=None)
    target_info = db.StringField(default=None, max_length=80)
    inspiration = db.StringField(default=None, max_length=80)
    quiz_type = db.StringField(default=None)


class Idea(db.Document):
  creator_id = db.StringField()
  assignee = db.StringField()
  assignee_id = db.StringField(default=None, null=True)
  title = db.StringField(max_length=255)
  details = db.EmbeddedDocumentField(Details)
  idea_type = db.StringField(default="draft", validation=lambda idea_type: idea_type in ["draft", "pitch"])
  status = db.StringField(default="drafted", validation=lambda status: status in ["new",  "approved", "parked", "rejected"])
  created_at = db.DateTimeField(default=datetime.today())
  updated_at = db.DateTimeField(default=datetime.today())
  approve_by_admin = db.IntField(default=0)
  reviewers = db.ListField(field=db.DictField(), default=lambda: [])
  pitch_approvals = db.ListField(field=db.DictField(null=True), default=lambda: [])
  title_approvals = db.ListField(field=db.DictField(null=True), default=lambda: [])
  vertical = db.StringField()
  goal = db.ReferenceField(Goal, dbref=True)
  meta = {'collection': 'ideas'}


class IdeaSchema(ModelSchema):
  class Meta:
    model = Idea


idea_schema = IdeaSchema()
ideas_schema = IdeaSchema(many=True)
