from datetime import datetime
import logging
import json
import uuid
import time

from flask import request
from flask_restplus import Resource, reqparse
from flask_jwt_extended import get_jwt_identity

from ..fields import idea_fields, update_idea_fields
from ..decorators import admin_required, login_required
from ..extensions import api
from ..models import Idea, idea_schema, ideas_schema, Goal, goal_schema, goals_schema, User, user_schema


# idea_parser = reqparse.RequestParser()
# idea_parser.add_argument('type', type=str, help='Must be one of [draft, pitch, title]')
# idea_parser.add_argument('user_id', type=str, help="User's public_id")

class IdeasEndpoint(Resource):
  def update_goal(self, assignee_username, body):
    real_assignee_username = body["assignee_username"]
    body["assignee_username"] = assignee_username
    print("The filter body is: ", body)
    # fetch the personal goals or global goals(if assignee_username = "Global")
    goals = Goal.objects(__raw__=body)
    print("The len for the filters is: ", len(goals))
    if len(goals) == 0:
      return
    goal = goals[0]
    print(goal_schema.dump(goal))
    goal.update(completed_number=goal["completed_number"] + 1)
    print("The completed_number for " + assignee_username + " has been updated")
    if assignee_username == "Global":
      stats = goal["stats"]
      print("The stats is: ", stats)
      if not real_assignee_username in stats:
          return False
      stats[real_assignee_username]["completed_number"] = stats[real_assignee_username]["completed_number"] + 1
      goal.update(stats=stats)
    return True

  @api.expect(idea_fields)
  def post(self):
    """Create a new pitch"""
    request_body = request.get_json(force=True)
    print("start to get the idea")
    idea, error = idea_schema.load(request_body)

    idea["created_at"] = datetime.today()
    idea["updated_at"] = datetime.today()
    goal = Goal.objects(deadline=request_body["deadline"], assignee_id="Global")[0]
    goal.save()
    idea['goal'] = goal.to_dbref()
    try:
      new_idea = idea.save()
    except Exception as e:
      print(str(e))
      return str(e), 400
    print("start to update pitch number")
    # + 1 to the global goal
    body = {
      "assignee_username": idea["creator_id"],
      "verticals": idea["vertical"],
      "deadline": request_body["deadline"]
    }

    print("start to update global goal")
    if not self.update_goal("Global", body):
      return {"ok": False, "msg": "A new pitch has been created. But there is no goal found for this vertical pitch!"}



    print("start to update personal goal")
    if not self.update_goal(idea["creator_id"], body):
        return {"ok": False, "msg": "A new pitch has been created. But there is no goal found for this pitch!"}

    print("A title has been created!")
    return {"ok": True, "msg": "Congratulation! A new pitch has been published"}

  @api.expect(idea_fields)
  def put(self):
    """Return a list of ideas with filters"""
    filters = request.get_json(force=True)
    print(filters)
    ideas = Idea.objects(__raw__=filters)
    return ideas_schema.dump(ideas)


class IdeaEndpoint(Resource):
  goals_logger = logging.getLogger('Goals')
  goals_logger.setLevel(logging.NOTSET)
  def get(self, idea_id):
    """Return a specific user entry."""

    idea = Idea.objects.get_or_404(id=idea_id)
    return idea_schema.dump(idea)

  @api.expect(idea_fields)
  def post(self, idea_id):
    """Update a idea"""
    idea = Idea.objects.get_or_404(id=idea_id)
    idea_patch = request.get_json(force=True)
    try:
        idea.update(**idea_patch, updated_at = datetime.today())
        # if idea_patch.get("idea_type") == "pitch" and idea_patch.get("approve_by_admin") == 0:
        #    idea.update(status="rejected", updated_at=datetime.utcnow)
        # if idea_patch.get("idea_type") == "pitch" and idea_patch.get("approve_by_admin") == 1:
        #    idea.update(status="parked", updated_at=datetime.utcnow)
        # if idea_patch.get("idea_type") == "pitch" and idea_patch.get("approve_by_admin") == 2:
        #    idea.update(status="approved", updated_at=datetime.utcnow)
    except Exception as e:
      print (str(e))
      return str(e),  400
    idea = Idea.objects.get_or_404(id=idea_id)
    if idea["status"] == "approved":
      date = idea["goal"]["deadline"]
      goal = Goal.objects(deadline=date, assignee_id="Global")[0]
      day = int(time.strftime("%w", time.localtime()))
      if day - 2 >= 0 and goal["stats"]["weekly_progress"][day - 1] == 0:
        goal["stats"]["weekly_progress"][day - 1] += goal["stats"]["weekly_progress"][day - 2]
      goal["stats"]["weekly_progress"][day - 1] += 1
      goal.save()

    return "Successed Saved", 200

  @api.expect(idea_fields)
  def put(self, idea_id):
    """Add a reviwer"""

    idea = Idea.objects.get_or_404(id=idea_id)


    reviewers = idea.reviewers
    if len(reviewers) >= 2:
      return "Too many reviwer!"
    raw_json = request.get_json(force=True)


    if len(reviewers) == 1 and  reviewers[0]["admin_id"] == raw_json["admin_id"]:
      print("duplicate reviewers")
      return "duplicate reviewers!"
    reviewers.append(raw_json)

    idea_patch = {
      "reviewers":reviewers
    }
    idea.update(**idea_patch, updated_at=datetime.today())

    self.goals_logger.error("ssss")

    if len(reviewers) == 2:
      reviewer_1 = reviewers[0]
      reviewer_2 = reviewers[1]
      if reviewer_1['status'] == 'approved' and reviewer_2['status'] == 'approved':
        idea.update(status="approved", updated_at=datetime.today())
        date = idea["goal"]["deadline"]
        goal = Goal.objects(deadline=date, assignee_id="Global")[0]
        day = int(time.strftime("%w", time.localtime()))
        if day - 2 >= 0 and goal["stats"]["weekly_progress"][day - 1] == 0:
          goal["stats"]["weekly_progress"][day - 1] += goal["stats"]["weekly_progress"][day - 2]
        goal["stats"]["weekly_progress"][day - 1] += 1
        goal.save()
      elif reviewer_1['status'] == 'rejected' and reviewer_2['status'] == 'rejected':
        idea.update(status="rejected", updated_at=datetime.today())
      else:
        idea.update(status="parked", updated_at=datetime.today())
    return idea_schema.dump(idea)


  def delete(self, idea_id):
    """Delete an idea"""

    idea = Idea.objects.get_or_404(id=idea_id)
    return idea.delete()