from datetime import datetime
import logging
import sys

from flask import request
from flask_restplus import Resource

from ..extensions import api
from ..fields import goal_fields
from ..models import Goal, goal_schema, goals_schema, User, user_schema


class GoalsEndpoint(Resource):
    goals_logger = logging.getLogger('Goals')
    goals_logger.setLevel(logging.NOTSET)

    @api.expect(goal_fields)
    def put(self):
        """Return a list of goals with filters"""
        filters = request.get_json(force=True)
        self.goals_logger.info('info Return a list of goals with filters: ')
        self.goals_logger.info(filters)


        goals = Goal.objects(__raw__=filters)


        return goals_schema.dump(goals)

    def patch(self):
        """Create/Update a list of goals """
        request_body = request.get_json(force=True)
        print("hello")
        print(request_body)
        deadline = request_body["deadline"]
        verticals = request_body["verticals"]

        print(deadline)
        print(verticals)
        for vertical in verticals:
            print(vertical)
            existed_goal = Goal.objects(verticals=vertical, deadline=deadline, assignee_id="Global")
            print("print goal")
            print()
            print(len(existed_goal))

            body = {
                "verticals": vertical,
                "deadline": deadline,
                "total_number": verticals[vertical]
            }
            if len(existed_goal) == 0:

                print("what is the body")
                print(body)
                self.create_goals(body)
            else:
                print("update")
                goal = existed_goal[0]
                self.update_goal(body, goal)

    def update_goal(self, goal_patch, goal):
        """Update a goal"""

        print("Start to update a new goal ", file=sys.stderr)
        try:
            goal.update(**goal_patch, updated_at = datetime.today())
        except Exception as e:
            print(e)
            return str(e), 400

        print("finish update global goal")
        try:
            new_total_number = goal_patch["total_number"]
        except Exception as e:
            print(e)
            new_total_number = goal.total_number

        print('start to update personal goals')
        if goal.personal_goals:

            print("show change content json: %s", goal_patch)

            personal_total_goals = int(new_total_number / len(goal.personal_goals))
            mark_idx = new_total_number % len(goal.personal_goals)

            for c, goal_id in enumerate(goal.personal_goals):
                print("idx: %d, goal_id: %s", c, goal_id)

                personal_goal = Goal.objects(id=str(goal_id))

                print("Personal goal %s has been fetched", personal_goal)


                if c < mark_idx:
                    goal_patch["total_number"] = personal_total_goals + 1
                else:
                    goal_patch["total_number"] = personal_total_goals

                print("The new goal patch is: %s", goal_patch)

                personal_goal.update(**goal_patch, updated_at = datetime.today())

        print("Global and personal goals have been changed", goal_patch)


    def create_goals(self, request_body):
        """Create a new goal"""
        print("request_body")
        print(request_body)
        self.goals_logger.info('Start to create a new goal')
        self.goals_logger.debug('The request body is: %s', request_body)

        goal, error = goal_schema.load(request_body)
        print("what is the request body")
        print(request_body)
        goal["assignee"] = "Global"
        goal["assignee_id"] = "Global"
        goal["assignee_username"] = "Global"
        goal["created_at"] = datetime.today()
        goal["updated_at"] = datetime.today()
        self.goals_logger.error(goal)
        # if error:
        #     self.goals_logger.error("Schema load error, check your request body!")
        #     return goal, 500

        # print("The goal body is : ", file=sys.stderr)
        # print(goal_schema.dump(goal), file=sys.stderr)

        contributors = User.objects(role="writer", is_active=True)
        len_contributors = len(contributors)
        total_goals = request_body["total_number"]
        if (len_contributors != 0):
            personal_total_goals = int(total_goals / len_contributors)
            self.goals_logger.debug('The personal total goals numbers is: %s', personal_total_goals)

            mark_idx = total_goals % len_contributors

            for c, contributor in enumerate(contributors):
                assignee_id = str(contributor.id)
                user = User.objects.get_or_404(id=contributor.id)
                user_name = user.first_name + ' ' + user.last_name
                self.goals_logger.debug("Start to create goal for %s", assignee_id)

                personal_goal = Goal(verticals=request_body["verticals"],
                                     assignee_username=contributor.username,
                                     assignee_id=assignee_id,
                                     assignee=user_name,
                                     deadline=request_body["deadline"],
                                     total_number=personal_total_goals,
                                     created_at=datetime.today(),
                                     updated_at=datetime.today()
                                     )

                if c < mark_idx:

                    personal_goal.total_number = personal_total_goals + 1
                personal_goal = personal_goal.save()
                goal.personal_goals.append(str(personal_goal.id))
                goal.contributors_id_list.append(str(personal_goal.assignee_id))
                goal.contributors_name_list.append(user_name)
                goal.stats[contributor.username] = {
                    "total_number": personal_goal.total_number,
                    "completed_number": personal_goal.completed_number,
                    "approved_number":personal_goal.approved_number,

                }
                goal.stats["weekly_progress"] = [0] * 7

        try:
            new_goal = goal.save()
            print('The new global goal has been saved!')
        except Exception as e:
            print("Fail to save, %s", str(e))
            return str(e), 400
        # TODO: Fan -- why there is two elements in the return lists?
        return goal_schema.dump(new_goal), 200

    @api.expect(goal_fields)
    def post(self):
        """Return goals for super admin goal board"""
        request_body = request.get_json(force=True)
        print("The request body is : ", request_body)
        global_goals = Goal.objects(deadline=request_body["deadline"], assignee_id="Global")
        if len(global_goals) == 0:
            print("cannot find the goals!"), 400
            resp = {
                "success": False,
                "message": "no result to return!"
            }
            return resp
        data = {
            "total_number" : [],
            "completed_number" : [],
            "contributor_list" : [],
            "verticals" : [],
            "created_time": "",
            "updated_time":"",
            "completed_stats": {},
            "deadline":request_body["deadline"]
        }

        for global_goal in global_goals:
            vertical = global_goal["verticals"]
            data["total_number"].append(global_goal["total_number"])
            data["completed_number"].append(global_goal["completed_number"])
            data["verticals"].append(vertical)
            data["contributor_list"] = global_goal["contributors_name_list"]
            data["created_time"] = str(global_goal["created_at"])
            data["updated_time"] = str(global_goal["updated_at"])
            data["completed_stats"][vertical] = global_goal["stats"]

        resp = {
            "success": True,
            "data": data,
        }

        return resp

class GoalsDashBoardEndpoint(Resource):
    def append_progress(self, data, tmp):

        if isinstance(data, int):
            return data + tmp
        res = {}
        for k, v in chain(data.items(), tmp.items()):
            print("The key is: ", k)
            if k != "weekly_progress": # TODO: if add more data to the stats, the future should modified to juedge typed
                if k in res:
                    res[k] = self.append_progress(res[k], v)
                else:
                    res[k] = v
        return res

    def post(self):
        """Return current week member's progres(all verticals and members for specific time)."""

        filters = request.get_json(force=True)
        filters["assignee_username"] = "Global"
        print("The filters is ", filters)
        goals = Goal.objects(__raw__=filters)

        if len(goals) == 0:
            return {"ok": False, "msg": "No work progress in database"}
        print("Start to sum data: ")
        data = {}
        for goal in goals:
            print("The stats is: ", goal["stats"])
            data = self.append_progress(data, goal["stats"])
        print("Finish append!")
        return {
            "ok": True,
            "data": data
        }
    def put(self, goal_id):
        """Return specific member's work progress(specific time and member)"""
        goal = Goal.objects.get_or_404(id=goal_id)
        return goal.delete()


class GoalEndpoint(Resource):
    goal_logger = logging.getLogger('Goal')
    goal_logger.setLevel(logging.NOTSET)
    def get(self, goal_id):
        """Return a specific goal."""
        goal = Goal.objects(id=goal_id)
        return goal_schema.dump(goal)

    def delete(self, goal_id):
        """Delete a goal"""
        goal = Goal.objects.get_or_404(id=goal_id)
        return goal.delete()

