from datetime import datetime

from flask_restplus import Resource

from ..decorators import admin_required, login_required
from ..extensions import api, bcrypt, db, jwt
from ..fields import user_fields, user_login_fields, updateable_user_fields
from ..models import User, user_list_schema, user_schema


class UserListEndpoint(Resource):
  # @admin_required
  def get(self):
    """Return a list of users."""

    return user_list_schema.dump(User.objects.order_by('username').paginate(page=1, per_page=20).items)

  @api.expect(user_fields)
  # @admin_required
  def post(self):
    """Create a new user."""
    user_data, error = user_schema.load(api.payload)
    users = User.objects(username=user_data["username"])
    if len(users) != 0:
      return {'msg': 'A user with that username already exists', "ok": False}

    if not isinstance(user_data, User):
      return {'msg': 'Bad request, check if all the lines with * have been filled!'}

    user_data.password = bcrypt.generate_password_hash(user_data.password).decode('utf-8')

    try:
      new_user = user_data.save()
    except error:
      return {'msg': 'A user with that username already exists', "ok": False}
    except Exception as e:
      return str(e), 403
    # return user_schema.dump(new_user)[0], 200
    return {'msg': 'A new user has been created!', "ok": True}


class UserEndpoint(Resource):
  # @admin_required
  def get(self, username):
    """Return a specific user entry."""

    user = User.objects.get_or_404(username=username)
    return user_schema.dump(user)

  @api.expect(updateable_user_fields)
  # @admin_required
  def put(self, username):
    """Update a user entry."""

    user_data, error = user_schema.load(api.payload)

    user = User.objects.get_or_404(username=username)
    user.update(updated_at=datetime.today(), **user_data)
    
    updated_user = User.objects.get_or_404(username=username)
    return user_schema.dump(updated_user)

  # @admin_required
  def delete(self, username):
    """Delete a specific user entry."""
    
    user = User.objects.get_or_404(username=username)
    user.delete()
    
    return {'msg': 'User `{}` was successfully deleted'.format(username)}, 200