from flask_restplus import Resource, fields
from flask_jwt_extended import create_access_token

from ..extensions import api, bcrypt, db
from ..fields import user_login_fields
from ..models import User, user_list_schema, user_schema



@api.expect(user_login_fields)
class Login(Resource):
  def post(self):
    """Login and authenticate a user."""

    user_data, error = user_schema.load(api.payload)
    
    if not isinstance(user_data, User):
      return {"msg": "Please enter a username and password"}, 400

    try:
      user = User.objects.get(username=user_data.username)
    except db.DoesNotExist:
      return {"msg": "The username entered does not exist"}, 400
    else:
      login_successful = bcrypt.check_password_hash(user.password, user_data.password)
      if not login_successful:
        return {"msg": "The password entered was incorrect"}, 400
      resp = {
        "token": create_access_token(identity=user_data.username),
        "user": user_schema.dump(user)
      }
      return resp, 200
        # user_schema.dump(user_data)
      # return create_access_token(identity=user_data.username), 200


class Logout(Resource):
  """Logout a user and revoke their token."""

  def post(self):
    pass