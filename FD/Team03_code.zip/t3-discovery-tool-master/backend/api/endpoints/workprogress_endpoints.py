from ..models import Idea, idea_schema, ideas_schema, Goal, goal_schema, goals_schema, User, user_schema
from flask_restplus import Resource
from flask import request
from itertools import chain

class WorkProgress(Resource):
  # @admin_required
  def post(self):
    """Return week's progress."""
    # return user_list_schema.dump(User.objects.order_by('username').paginate(page=1, per_page=20).items)
    request_body = request.get_json(force=True)
    date = request_body['date']
    try:
      goal = Goal.objects(deadline=date, assignee_id="Global")[0]
      stats = goal["stats"]
      total_number = goal["total_number"]
      ret = [0] * 7
      print (stats["weekly_progress"])
      for index, num in enumerate(stats["weekly_progress"]):
        ret[index] = int(num * 100 / total_number)

      return {
        'success': True,
        'data': {
          'date': date,
          'weekly_progress': ret
        }
      }
    except Exception as e:
      return {
        'success': False,
        'message': str(e)
      }

  def append_progress(self, data, tmp):

      if isinstance(data, int):
          return data + tmp
      res = {}
      for k, v in chain(data.items(), tmp.items()):
          print("The key is: ", k)
          if k != "weekly_progress": # TODO: if add more data to the stats, the future should modified to juedge typed
              if k in res:
                  res[k] = self.append_progress(res[k], v)
              else:
                  res[k] = v
      return res

  def patch(self):
      """Return current week member's progres(all verticals and members for specific time)."""

      filters = request.get_json(force=True)
      filters["assignee_username"] = "Global"
      print("The filters is ", filters)
      goals = Goal.objects(__raw__=filters)

      if len(goals) == 0:
          return {"ok": False, "msg": "No work progress in database"}
      print("Start to sum data: ")
      data = {}
      for goal in goals:
          print("The stats is: ", goal["stats"])
          data = self.append_progress(data, goal["stats"])
      print("Finish append!")
      return {
          "ok": True,
          "data": data,
          "date": filters["deadline"]
      }
  def put(self, goal_id):
      """Return specific member's work progress(specific time and member)"""
      goal = Goal.objects.get_or_404(id=goal_id)
      return goal.delete()
