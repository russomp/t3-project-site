# ![T3 Discovery Tool](https://greenbay.usc.edu/csci577/fall2018/projects/team03/assets/img/t3-nav-logo.png)

A web-based tool for streamlining the idea management and content approval process by allowing CMS teams to set and track content goals, pitch ideas, and monitor weekly progress with ease

## Getting started

Install Postman
```
Visit https://www.getpostman.com/apps
Download and install Postman
```

Set up mongoDB locally

Install mongoDB
```
visit https://www.mongodb.com/download-center
sign up an account, download and install mongoDB
```

Install Compass, the intuitive GUI for mongoDB
```
visit https://www.mongodb.com/download-center/compass
download and install compass
```

In the shell console, launch mongoDB
```
mongod
```

Launch Compass and access the database
```
Connect to a new host with the following configurations:
Hostname: localhost
Port: 27017
Authentication: None
Read Preference: Primary
SSL: None
SSH Tunnel: None
Favorite Name: <anything of your like>

click 'CONNECT' button
Once connected, click 'CREATE DATABASE' to create a database <name> for the system
In the side bar, open the newly created database <name>, click 'CREATE COLLECTION' to create the following collections, leave 'Capped Collection' and 'Use Custom Collation' unselected:

goals
ideas
users
```


Clone the repository

```
git clone https://github.com/russomp/t3-discovery-tool.git
```

You'll find two main folders for running the the frontend and backend separately.

To run the client-side React app locally, simply change directories into `frontend/` and run the app using [npm](https://docs.npmjs.com/downloading-and-installing-node-js-and-npm) scripts.

```
cd frontend/
npm install
npm start
```

To run the Flask API, simply change directories to `backend/` and run the server via commands in `manage.py`.

```
cd backend/
pip install pipenv
pipenv shell
pipenv install

python manage.py run
```

Note: The app was built using Python 3.7. If you are having version issues, try downloading [pyenv](https://github.com/pyenv/pyenv) and using it to install Python 3.7.0 and set it as your working version for this project.


Note: If the mongDB database is hosted locally, for testing purpose, send a request from Postman to the backend to create a superadmin
```
Send a POST request to http://localhost:5000/api/users with the following raw JSON in the 'body' tab:
{
  "username": "superadmin",
  "password": "supersecret",
  "first_name": "super",
  "last_name": "admin",
  "role": "superadmin"
}
```

## Using the app

Once you have both apps running locally in separate terminal windows, you should be able to navigate to `http://localhost:3000/login` and log in to the platform using any of the following credentials.

```
Superadmin
username: superadmin
password: supersecret


Admins
username: admin1
password: secret

username: admin2
password: secret


Content Contributors
username: writer1
password: secret

username: writer2
password: secret
```

You can also create new users with the Superadmin account, and share other usernames/passwords with your team.

## Backend API docs

You can also access the beackend API Swagger docs directly via `http://127.0.0.1:5000/`. From there, you can view the different resources available via the API, and event test endpoints.

## Licensing

This tool was developed for [System 1](https://system1.com/) as part of a school project for cs577a at USC over the Fall 2018 semester.
