## [1.0.0] 2018-10-14
### First Draft Design for ARB presentation
- Create frontend template based on material-dashboard-react created by creative Tim
- Implement Login page
- Implement Admin page, including dashboard, pitchboard, titlebard, goal board, team member page, etc.
- Implement Content creator page, including homepage, draftboard, global pitch board, local title boar, etc.
