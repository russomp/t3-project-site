// Config, do not change here
// const LOCAL_WEBSITE = '';
// const REMOTE_WEBSITE = '';

// Switch your Domain here!
// const Domain = LOCAL_WEBSITE;
const API_ROOT = `${process.env.REACT_APP_API_ROOT}/api`;

export const GOAL_URL = `${API_ROOT}/goals`;
export const PITCHES_URL = `${API_ROOT}/ideas/`;
export const USERS_URL = `${API_ROOT}/users`;

export const CREATE_PITCH = `${API_ROOT}/ideas/`;
export const LOGIN = `${API_ROOT}/auth/login`;
export const LOAD_WEEKLY_PROGRESS = `${API_ROOT}/workprogress`;
