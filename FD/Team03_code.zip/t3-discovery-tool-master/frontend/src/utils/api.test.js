import api from './api';

describe('Axios config', () => {
  test('makes the correct request', done => {
    api
      .get('/auth/login', { username: 'admin', password: 'password' })
      .then(response => {
        done();
      })
      .catch(e => {
        console.log(e);
        done();
      });
  });
});
