import axios from 'axios';

const API_ROOT = `${process.env.REACT_APP_API_ROOT}/api`;
const API_KEY = window.sessionStorage
  ? window.sessionStorage.getItem('user_key')
  : '';

const api = axios.create({
  baseURL: API_ROOT,
  timeout: 1000,
  headers: {
    Authorization: `Bearer ${API_KEY}`,
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  },
});

export default api;
