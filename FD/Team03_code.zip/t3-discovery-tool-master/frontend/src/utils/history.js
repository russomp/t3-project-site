// src/history.js

import createHistory from "history/createBrowserHistory";

export default createHistory();
