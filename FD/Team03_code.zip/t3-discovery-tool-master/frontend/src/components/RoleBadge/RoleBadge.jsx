import React from 'react';

import Badge from '../Badge/Badge';

export default ({ role }) => {
  switch (role) {
    case 'superadmin': {
      return <Badge color="danger">{role}</Badge>;
    }
    case 'admin': {
      return <Badge color="warning">{role}</Badge>;
    }
    case 'writer': {
      return <Badge color="info">{role}</Badge>;
    }
    default: {
      return <Badge />;
    }
  }
};
