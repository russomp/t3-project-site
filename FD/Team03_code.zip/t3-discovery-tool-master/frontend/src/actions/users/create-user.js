import swal from 'sweetalert';

import { USERS_URL } from '../../utils/urls';
import { loadAllUsers } from './load-all-users.js';

export const request = 'CREATE_USER_REQUEST';
export const success = 'CREATE_USER_SUCCESS';
export const failure = 'CREATE_USER_FAIL';

export const createUsersRequest = payload => ({
  type: request,
  payload,
});

export const createUsersSuccess = payload => ({
  type: success,
  payload,
});

export const createUsersFailure = payload => ({
  type: failure,
  payload,
});

export const createUsers = body => (dispatch, getState) => {
  dispatch(createUsersRequest(false));

  fetch(USERS_URL, {
    method: 'post',
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
    },
    body,
  })
    .then(response => {
      if (response.ok) {
      } else {
        dispatch(createUsersFailure());
      }
      return response.json();
    })
    .then(data => {
      const type = data.ok ? 'success' : 'error';
      swal(data.msg, '', type);
      dispatch(loadAllUsers());
      const payload = {
        data,
      };
      dispatch(createUsersSuccess(payload));
    })
    .catch(error => {
      dispatch(createUsersFailure(false));
    });
};
