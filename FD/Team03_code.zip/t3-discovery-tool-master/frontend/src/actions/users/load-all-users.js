import { USERS_URL } from '../../utils/urls';

export const request = 'LOAD_ALL_USERS_REQUEST';
export const success = 'LOAD_ALL_USERS_SUCCESS';
export const failure = 'LOAD_ALL_USERS_FAILURE';

export const loadUsersRequest = payload => ({
  type: request,
  payload,
});

export const loadUsersSuccess = payload => ({
  type: success,
  payload,
});

export const loadUsersFailure = payload => ({
  type: failure,
  payload,
});

export const loadAllUsers = body => (dispatch, getState) => {
  dispatch(loadUsersRequest());

  fetch(USERS_URL, {
    method: 'get',
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Credentials': '*',
    },
    body,
  })
    .then(response => response.json())
    .then(data => {
      let payload = {
        data,
      };

      dispatch(loadUsersSuccess(payload));
    })
    .catch(error => {
      dispatch(loadUsersFailure());
    });
};
