import { loadAllUsers } from "./load-all-users";
import { USERS_URL } from "../../utils/urls";

export const updateUserByUsername = (body, username) => dispatch => {
  const url = `${USERS_URL}/${username}`;
  fetch(url, {
    method: "PUT",
    credentials: "include",
    headers: {
      "Content-Type": "application/json"
    },
    body
  }).then(response => {
    if (response.ok) {
      dispatch(loadAllUsers());
    }
  });
};
