import { loadAllUsers } from "./load-all-users";
import { USERS_URL } from "../../utils/urls";

export const deleteUserByUsername = (username) => dispatch => {
  const url = `${USERS_URL}/${username}`;
  fetch(url, {
    method: "delete",
    credentials: "include",
    headers: {
      "Content-Type": "application/json"
    }
  }).then(response => {
    if (response.ok) {
      dispatch(loadAllUsers());
    }
  });
};
