import { GOAL_URL } from "../../utils/urls";

export const request = "LOAD_ALL_BUNCHES_GOALS_REQUEST";
export const success = "LOAD_ALL_BUNCHES_GOALS_SUCCESS";
export const failure = "LOAD_ALL_BUNCHES_GOALS_FAILURE";

export const loadBunchesGoalsRequest = payload => ({
  type: request,
  payload
});

export const loadBunchesGoalsSuccess = payload => ({
  type: success,
  payload
});

export const loadBunchesGoalsFailure = payload => ({
  type: failure,
  payload
});

export const loadBunchesGoals = body => (dispatch, getState) => {
  dispatch(loadBunchesGoalsRequest());
  fetch(GOAL_URL, {
    method: "post",
    credentials: "include",
    headers: {
      "Content-Type": "application/json"
    },
    body
  })
    .then(response => response.json())
    .then(data => {
      let payload = {
        data
      };

      dispatch(loadBunchesGoalsSuccess(payload));
    })
    .catch(error => {
      dispatch(loadBunchesGoalsFailure());
    });
};
