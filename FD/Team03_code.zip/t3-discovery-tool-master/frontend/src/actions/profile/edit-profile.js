import api from '../../utils/api';

export const EDIT_PROFILE_PENDING = 'UPDATE_USER_PENDING';
export const EDIT_PROFILE_SUCCESS = 'UPDATE_USER_SUCCESS';
export const EDIT_PROFILE_FAILURE = 'UPDATE_USER_FAILURE';

export const editProfile = (username, updatedUserdata) => dispatch => {
  dispatch({ type: EDIT_PROFILE_PENDING });
  api
    .put(`/users/${username}`, updatedUserdata)
    .then(response =>
      dispatch({ type: EDIT_PROFILE_SUCCESS, payload: response })
    )
    .catch(error =>
      dispatch({ type: EDIT_PROFILE_FAILURE, payload: error.message })
    );
};
