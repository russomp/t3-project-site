import { LOGIN } from "../../utils/urls";
import history from "../../utils/history.js";

export const request = "LOGIN_REQUEST";
export const success = "LOGIN_SUCCESS";
export const failure = "LOGIN_FAILURE";

export const loginRequest = payload => ({
  type: request,
  payload
});

export const loginSucess = payload => ({
  type: success,
  payload
});

export const loginFail = payload => ({
  type: failure,
  payload
});

export const login = body => (dispatch, getState) => {
  dispatch(loginRequest());
  fetch(LOGIN, {
    method: "post",

    credentials: "include",
    headers: {
      "Content-Type": "application/json"
    },
    body
  })
    .then(response => response.json())
    .then(data => {
      let payload = {
        data
      };
      const role = data.user[0].role;
      localStorage.setItem("userInfo", JSON.stringify(data.user[0]));
      window.sessionStorage.setItem("user_key", data.token);
      switch (role) {
        case "writer":
          history.push("./content-contributor");
          break;
        case "admin":
          history.push("./content-admin");
          break;
        case "superadmin":
          history.push("./super-admin");
          break;
        default:
          break;
      }
      dispatch(loginSucess(payload));
    })
    .catch(error => {
      console.log(error);
      dispatch(loginFail(error));
    });
};
