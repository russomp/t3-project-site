import {
  LOGIN_USER_PENDING,
  LOGIN_USER_SUCCESS,
  LOGIN_USER_FAILED,
} from './actionTypes';

import api from '../../utils/api';

// export const setSearchField = text => ({
//   type: CHANGE_SEARCH_FIELD,
//   payload: text,
// });

export const loginUser = ({ username, password }, history) => dispatch => {
  dispatch({ type: LOGIN_USER_PENDING });
  api
    .post('/auth/login', { username, password })
    .then(response => dispatch({ type: LOGIN_USER_SUCCESS, payload: response }))
    .catch(error =>
      dispatch({ type: LOGIN_USER_FAILED, payload: error.message })
    );
};
