import { LOAD_WEEKLY_PROGRESS } from "../../utils/urls";

export const loadWeekProgress = (body) => {
  return new Promise((resolve, reject) => {
    fetch(LOAD_WEEKLY_PROGRESS, {
      method: "post",
      credentials: "include",
      headers: {
        "Content-Type": "application/json"
      },
      body
    })
    .then(response => response.json())
    .then(data => {
      resolve(data);
    })
    .catch(error => {
      console.log(error);
    });
  })
};

export const loadMemberProgress = (body) => {
  return new Promise((resolve, reject) => {
    fetch(LOAD_WEEKLY_PROGRESS, {
      method: "PATCH",
      credentials: "include",
      headers: {
        "Content-Type": "application/json"
      },
      body
    })
    .then(response => response.json())
    .then(data => {
      resolve(data);
    })
    .catch(error => {
      console.log(error);
    });
  })
};
