import Pages from "layouts/Pages.jsx";
import Dashboard from "layouts/Dashboard.jsx";

var indexRoutes = [
  { path: "/super-admin", component: Dashboard, auth: true },
  { path: "/content-admin", component: Dashboard, auth: true},
  { path: "/content-contributor", component: Dashboard, auth: true},
  { path: "/", component: Pages, auth: false}
];

export default indexRoutes;
