// @material-ui/icons
import Dashboard from '@material-ui/icons/Dashboard';
// import ContentPaste from "@material-ui/icons/ContentPaste";

import Settings from "@material-ui/icons/Settings";
// core components/views
import DashboardPage from "../containers/Dashboard.js";
import DraftBoard from "../containers/DraftBoard.js";
import LibraryBooks from "@material-ui/icons/LibraryBooks";
import PitchBoard from "../containers/PitchBoard";
import ProfilePage from '../containers/Profile';


const superDashboardRoutes = [
  {
    path: '/content-contributor/dashboard',
    name: 'Dashboard',
    icon: Dashboard,
    component: DashboardPage,
  },
  {
    path: '/content-contributor/draft',
    name: 'Draft Board',
    icon: 'content_paste',
    component: DraftBoard,
  },
  {
    path: '/content-contributor/pitch',
    name: 'Global Pitch Board',
    icon: LibraryBooks,
    component: PitchBoard,
  },
  {
    path: '/content-contributor/setting',
    name: 'Settings',
    icon: Settings,
    component: ProfilePage,
  },
  {
    redirect: true,
    path: '/content-contributor',
    to: '/content-contributor/dashboard',
    name: 'Redirect',
  },
  {
    redirect: true,
    path: '/content-contributor',
    to: '/content-contributor/dashboard',
    name: 'Redirect',
  },
];

export default superDashboardRoutes;
