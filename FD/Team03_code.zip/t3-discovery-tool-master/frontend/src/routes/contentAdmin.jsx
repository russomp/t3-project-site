// @material-ui/icons
import Dashboard from '@material-ui/icons/Dashboard';
// import ContentPaste from "@material-ui/icons/ContentPaste";
import LibraryBooks from "@material-ui/icons/LibraryBooks";
import Settings from "@material-ui/icons/Settings";
import Group from "@material-ui/icons/Group";
// core components/views
import DashboardPage from "views/Dashboard/Dashboard.jsx";
import TeamMember from "../containers/TeamBoaard.js";
import PitchBoard from "../containers/PitchBoard.js";
import ProfilePage from '../containers/Profile';

const contentAdminDashboardRoutes = [
  {
    path: '/content-admin/dashboard',
    name: 'Dashboard',
    icon: Dashboard,
    component: DashboardPage,
  },
  {
    path: '/content-admin/pitch',
    name: 'Global Pitch Board',
    icon: LibraryBooks,
    component: PitchBoard,
  },
  {
    path: '/content-admin/team',
    name: 'Team Member',
    icon: Group,
    component: TeamMember,
  },
  {
    path: '/content-admin/setting',
    name: 'Settings',
    icon: Settings,
    component: ProfilePage,
  },
  {
    redirect: true,
    path: '/content-admin',
    to: '/content-admin/dashboard',
    name: 'Redirect',
  },
];

export default contentAdminDashboardRoutes;
