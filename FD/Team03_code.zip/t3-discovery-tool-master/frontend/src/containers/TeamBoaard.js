import { connect } from "react-redux";
import TeamMember from "../views/TeamMember/TeamMember";
import { bindActionCreators } from "redux";
import { loadAllUsers } from "../actions/users/load-all-users";
import { createUsers } from "../actions/users/create-user";
import { updateUserByUsername } from "../actions/users/update-user-by-username";
import { deleteUserByUsername } from "../actions/users/delete-user-by-username";

const mapStateToProps = state => {
  return {
    allUsers: state.allUsers
  };
};
const mapDispatchToProps = dispatch => ({
  createUsers: bindActionCreators(createUsers, dispatch),
  loadAllUsers: bindActionCreators(loadAllUsers, dispatch),
  updateUserByUsername: bindActionCreators(updateUserByUsername, dispatch),
  deleteUserByUsername: bindActionCreators(deleteUserByUsername, dispatch)
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TeamMember);
