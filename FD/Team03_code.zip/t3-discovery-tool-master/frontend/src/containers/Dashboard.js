import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { loadGoalsByFilters } from "../actions/goals/load-goals-by-filters";
import { createGoals } from "../actions/goals/create-goals";
import Dashboard from "../views/Dashboard/Dashboard";
import { loadPitchesByFilters } from "../actions/pitches/load-pitches-by-filters";

const mapStateToProps = state => {
  return {
    pitches: state.pitchesByFilters,
    goals: state.goalsByFilters
  };
};
const mapDispatchToProps = dispatch => ({
  loadPitchesByFilters: bindActionCreators(loadPitchesByFilters, dispatch),
  loadGoalsByFilters: bindActionCreators(loadGoalsByFilters, dispatch),
  createGoals: bindActionCreators(createGoals, dispatch)
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Dashboard);
