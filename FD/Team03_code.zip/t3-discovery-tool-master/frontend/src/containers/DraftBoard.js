import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import DraftBoard from "../views/DraftBoard/DraftBoard";
import { loadBunchesGoals } from "../actions/goals/load-bunches-goals";

const mapStateToProps = state => {
  return {
    bunchesGoals: state.bunchesGoals
  };
};
const mapDispatchToProps = dispatch => ({
  loadBunchesGoals: bindActionCreators(loadBunchesGoals, dispatch)
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DraftBoard);
