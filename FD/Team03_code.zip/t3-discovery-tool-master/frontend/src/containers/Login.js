import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import LoginPage from "../views/Pages/LoginPage";
import { login } from "../actions/auth/login";

const mapStateToProps = state => {
  return {
    loginInfo: state.login
  };
};
const mapDispatchToProps = dispatch => ({
  login: bindActionCreators(login, dispatch)
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LoginPage);
