import { connect } from 'react-redux';
import SettingPage from '../views/Setting';
import { bindActionCreators } from 'redux';
import { editProfile } from '../actions/profile/edit-profile';

const mapStateToProps = state => {
  return {
    profile: state.profile,
    currentUser: state.login.data,
  };
};
const mapDispatchToProps = dispatch => ({
  editProfile: bindActionCreators(editProfile, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SettingPage);
