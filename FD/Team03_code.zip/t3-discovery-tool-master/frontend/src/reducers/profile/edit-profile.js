import swal from 'sweetalert';

import {
  EDIT_PROFILE_PENDING,
  EDIT_PROFILE_SUCCESS,
  EDIT_PROFILE_FAILURE,
} from '../../actions/profile/edit-profile';

export const initialState = {
  first_name: '',
  last_name: '',
  city: '',
  state: '',
  country: '',
  isLoading: false,
};

export const editProfile = (state = initialState, action) => {
  switch (action.type) {
    case EDIT_PROFILE_PENDING: {
      return {
        ...state,
        isLoading: true,
      };
    }
    case EDIT_PROFILE_SUCCESS: {
      swal(
        'Your profile was updated successfully!',
        JSON.stringify(action.payload.data, null, 2)
      );
      const {
        first_name,
        last_name,
        city,
        state,
        country,
      } = action.payload.data;
      return {
        first_name,
        last_name,
        city,
        state,
        country,
        isLoading: false,
      };
    }
    case EDIT_PROFILE_FAILURE: {
      swal(
        'Oops! Something went wrong while updating your profile.',
        action.payload,
        'error'
      );
      return {
        ...state,
        isLoading: false,
      };
    }
    default: {
      return state;
    }
  }
};
