import { combineReducers } from 'redux';
import { initialSateLogin, login } from './auth/login';
import {
  goalsByFilters,
  initialState as goalsByFiltersInitialState,
} from './goals/goals-by-filters';
import {
  initialState as pitchesByFiltersInitialState,
  pitchesByFilters,
} from './pitches/pitches-by-filters';
import {
  allUsers,
  initialState as allUsersInitialState,
} from './users/all-users';
import {
  editProfile,
  initialState as initialProfileState,
} from './profile/edit-profile';
import {
  initialState as bunchesGoalsInitialState,
  bunchesGoals
} from "./goals/bunches-goals";

/*
 * We combine all reducers into a single object before updated data is dispatched (sent) to store
 * Your entire applications state (store) is just whatever gets returned from all your reducers
 * */

export const initialState = {
  allUsers: allUsersInitialState,
  login: initialSateLogin,
  goalsByFilters: goalsByFiltersInitialState,
  pitchesByFilters: pitchesByFiltersInitialState,
  profile: initialProfileState,
  bunchesGoals: bunchesGoalsInitialState
};
export const appReducer = combineReducers({
  allUsers,
  login,
  goalsByFilters,
  pitchesByFilters,
  profile: editProfile,
  bunchesGoals
});

export const rootReducer = (state, action) => {
  // if (action.type === SIGN_OUT_REQUEST || action.type === CHECK_AUTH_FAILURE) {
  //     if (!FOR_LOCALHOST) state = initialState;
  // }
  return appReducer(initialState, action);
};
