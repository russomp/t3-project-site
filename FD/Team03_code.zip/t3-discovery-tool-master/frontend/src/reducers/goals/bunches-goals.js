import {
  request,
  success,
  failure
} from "../../actions/goals/load-bunches-goals";

export const initialState = {
  data: {},
  isLoading: false
};

export const bunchesGoals = (state = initialState, action) => {
  switch (action.type) {
    case request: {
      return {
        ...state,
        isLoading: true
      };
    }
    case success: {
      state.data = action.payload.data;
      console.log("reducer data");
      console.log(state.data);
      console.log(action.payload.data);

      return {
        ...state,
        isLoading: false
      };
    }

    case failure:
      return {
        ...state,
        isLoading: false
      };
    default:
      break;
  }
  return state;
};
