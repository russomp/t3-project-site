import { request, success, failure } from "./../../actions/auth/login.js";

export const initialSateLogin = {
  isPending: false,
  isAuthenticated: false,
  error: "",
  data: {},
  isFail: false
};

export const login = (state = initialSateLogin, action = {}) => {
  switch (action.type) {
    case request:
      return { ...state, isPending: true };
    case success:
      state.data = action.payload.data.user[0];
      state.isAuthenticated = true;
      window.sessionStorage.setItem("user_key", action.payload.data.token);
      return {
        ...state,
        isPending: false,
        isAuthenticated: true,
        data: action.payload.data.user[0]
      };
    case failure:
      return {
        ...state,
        isPending: false,
        isAuthenticated: false,
        error: action.payload,
        isFail: true
      };
    default:
      return state;
  }
};

export default login;
