import React from "react";
import { createPitch } from "../../actions/pitches/create-pitches.js";
// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
import FormLabel from "@material-ui/core/FormLabel";
// @material-ui/icons
import moment from "moment";
// core components
import GridContainer from 'components/Grid/GridContainer.jsx';
import GridItem from 'components/Grid/GridItem.jsx';
import CustomInput from 'components/CustomInput/CustomInput.jsx';
import Button from 'components/CustomButtons/Button.jsx';
import Card from 'components/Card/Card.jsx';
import CardHeader from 'components/Card/CardHeader.jsx';
import CardText from 'components/Card/CardText.jsx';
import CardBody from 'components/Card/CardBody.jsx';
import FormControl from '@material-ui/core/FormControl';

import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import swal from 'sweetalert';


import regularFormsStyle from "assets/jss/material-dashboard-pro-react/views/regularFormsStyle";
import { loadGoal } from "../../actions/goals/load-goals-by-filters";
import { get } from "lodash";

class DraftBoard extends React.Component {
  constructor(props) {
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));

    super(props);
    let verticals = [];
    const body = {
      deadline: `${moment().year()}-${moment().week()}`,
    };

    loadGoal(JSON.stringify(body))
      .then(data => {
        verticals = data.data.verticals;
      })
      .catch(err => {
        console.log(err);
      });
    this.state = {
      verticals: verticals,
      pitchInfo: {
        title: '',
        status: 'new',
        idea_type: 'pitch',
        creator_id: userInfo.username,
        vertical: '',
        deadline: '',
        details: {
          url: '',
          description: '',
          network: '',
          quiz_type: '',
          inspiration: '',
          target_info: '',
        },
      },
    };
    this.handleSelect = this.handleSelect.bind(this);
    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleSubmitPitch = this.handleSubmitPitch.bind(this);
  }

  UNSAFE_componentWillMount() {
    const body = {
      deadline: `${moment().year()}-${moment().week()}`,
    };
    this.props.loadBunchesGoals(JSON.stringify(body));
  }

  handleSelect(event) {
    this.setState({ [event.target.name]: event.target.value });
  }

  handleInputChange = name => event => {
    const { pitchInfo } = this.state;
    pitchInfo[name] = event.target.value;
    this.setState({
      pitchInfo: pitchInfo,
    });
  };
  handleDetailInputChange = name => event => {
    const { pitchInfo } = this.state;
    pitchInfo.details[name] = event.target.value;
    this.setState({
      pitchInfo: pitchInfo,
    });
  };


  handleSubmitPitch() {
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));
    const body = this.state.pitchInfo;

    if (body.title.length === 0 || body.vertical.length === 0) {
      swal("Please fill required item!!", "", "error");
      return;
    }

    if (!userInfo || !userInfo.username) {
      swal('Please login in!', '', 'error');
      return;
    }
    body['creator_id'] = userInfo.username;

    body['deadline'] = `${moment().year()}-${moment().week()}`;

    createPitch(JSON.stringify(body)).then(ret => {
      if (ret.ok) {
        swal(ret.msg, "", "success");
      } else {
        swal(ret.msg, "", "warning");
      }
    });
  }

  render() {
    const { bunchesGoals, classes } = this.props;
    const verticals = get(bunchesGoals, 'data.data.verticals', []);
    const verticalMenuList = verticals.map((menu, key) => {
      return (
        <MenuItem
          classes={{
            root: classes.selectMenuItem,
            selected: classes.selectMenuItemSelected,
          }}
          value={menu}
        >
          {menu}
        </MenuItem>
      );
    });
    return (
      <div style={{ overflowX: 'hidden' }}>
        <GridContainer>
          <GridItem xs={12} sm={12} md={12}>
            <Card>
              <CardHeader color="rose" text>
                <CardText color="rose">
                  <h4 className={classes.cardTitle}>Pitch Draft</h4>
                </CardText>
              </CardHeader>
              <CardBody>
                <form>
                  <GridContainer>
                    <GridItem xs={12} sm={12}>
                      <FormLabel
                        xs={12}
                        sm={10}
                        className={classes.labelLeftHorizontal}
                      >
                        * Required Info:
                      </FormLabel>
                    </GridItem>

                    <GridItem xs={5} sm={1}>
                      <FormLabel className={classes.labelHorizontal}>
                        * Title
                      </FormLabel>
                    </GridItem>
                    <GridItem xs={5} sm={5} md={5} lg={5}>
                      <CustomInput
                        id="title"
                        formControlProps={{
                          fullWidth: true,
                        }}
                        inputProps={{
                          onChange: this.handleInputChange('title'),
                          type: 'text',
                        }}
                      />
                    </GridItem>
                    <GridItem xs={5} sm={2}>
                      <FormLabel className={classes.labelHorizontal}>
                        * Vertical
                      </FormLabel>
                    </GridItem>
                    <GridItem xs={5} sm={4} style={{ marginTop: '25px' }}>
                      <FormControl
                        fullWidth
                        className={classes.selectFormControl}
                      >
                        <Select
                          MenuProps={{
                            className: classes.selectMenu,
                          }}
                          classes={{
                            select: classes.select,
                          }}
                          value={this.state.pitchInfo.vertical}
                          onChange={this.handleInputChange('vertical')}
                          inputProps={{
                            name: 'vertical',
                            id: 'vertical',
                          }}
                        >
                          {verticalMenuList}
                        </Select>
                      </FormControl>
                    </GridItem>

                    <GridItem xs={12} sm={12}>
                      <FormLabel
                        xs={12}
                        sm={10}
                        className={classes.labelLeftHorizontal}
                      >
                        Details:
                      </FormLabel>
                    </GridItem>

                    <GridItem xs={5} sm={1}>
                      <FormLabel className={classes.labelHorizontal}>
                        URL
                      </FormLabel>
                    </GridItem>
                    <GridItem xs={5} sm={5} md={5} lg={5}>
                      <CustomInput
                        id="url"
                        formControlProps={{
                          fullWidth: true,
                        }}
                        inputProps={{
                          onChange: this.handleDetailInputChange('url'),
                          type: 'text',
                        }}
                      />
                    </GridItem>
                    <GridItem xs={5} sm={2}>
                      <FormLabel className={classes.labelHorizontal}>
                        Buy-side Network
                      </FormLabel>
                    </GridItem>
                    <GridItem xs={5} sm={4}>
                      <CustomInput
                        id="network"
                        formControlProps={{
                          fullWidth: true,
                        }}
                        inputProps={{
                          onChange: this.handleDetailInputChange('network'),
                          type: 'text',
                        }}
                      />
                    </GridItem>

                    <GridItem xs={5} sm={1}>
                      <FormLabel className={classes.labelHorizontal}>
                        Target Info
                      </FormLabel>
                    </GridItem>
                    <GridItem xs={5} sm={5} md={5} lg={5}>
                      <CustomInput
                        id="target_info"
                        formControlProps={{
                          fullWidth: true,
                        }}
                        inputProps={{
                          onChange: this.handleDetailInputChange('target_info'),
                          type: 'text',
                        }}
                      />
                    </GridItem>

                    <GridItem xs={5} sm={2}>
                      <FormLabel className={classes.labelHorizontal}>
                        Quiz Type
                      </FormLabel>
                    </GridItem>
                    <GridItem xs={5} sm={4}>
                      <CustomInput
                        id="quiz_type"
                        formControlProps={{
                          fullWidth: true,
                        }}
                        inputProps={{
                          onChange: this.handleDetailInputChange('quiz_type'),
                          type: 'text',
                        }}
                      />
                    </GridItem>
                    <GridItem
                      xs={10}
                      sm={10}
                      md={10}
                      lg={10}
                      style={{ marginLeft: '40px' }}
                    >
                      <CustomInput
                        labelText="Inspiration"
                        id="description"
                        formControlProps={{
                          fullWidth: true,
                        }}
                        inputProps={{
                          multiline: true,
                          onChange: this.handleDetailInputChange('inspiration'),
                          rows: 2,
                          type: 'text',
                        }}
                      />
                    </GridItem>

                    <GridItem
                      xs={10}
                      sm={10}
                      md={10}
                      lg={10}
                      style={{ marginLeft: '40px' }}
                    >
                      <CustomInput
                        labelText="Description"
                        id="description"
                        formControlProps={{
                          fullWidth: true,
                        }}
                        inputProps={{
                          onChange: this.handleDetailInputChange('description'),
                          multiline: true,
                          rows: 5,
                          name: 'description',
                        }}
                      />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={12} lg={12}>
                      <Button
                        color="rose"
                        round
                        className={classes.marginRight}
                        onClick={this.handleSubmitPitch}
                      >
                        pitch it!
                      </Button>
                    </GridItem>
                  </GridContainer>
                </form>
              </CardBody>
            </Card>
          </GridItem>
        </GridContainer>
      </div>
    );
  }
}

export default withStyles(regularFormsStyle)(DraftBoard);
