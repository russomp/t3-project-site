import React from "react";
// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
// material-ui icons
import Assignment from "@material-ui/icons/Assignment";
import MoreHoriz from "@material-ui/icons/MoreHoriz";
import SaveButton from "@material-ui/core/Button";
// core components
import GridContainer from "components/Grid/GridContainer.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import Table from "components/Table/Table.jsx";
import Button from "components/CustomButtons/Button.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import Card from "components/Card/Card.jsx";

import extendedTablesStyle from "assets/jss/material-dashboard-pro-react/views/extendedTablesStyle.jsx";
import Edit from "@material-ui/icons/Edit";
import EditDialog from "./EditDialog";
import DetailDialog from "./DetailDialog";
import { CSVLink } from "react-csv";
import SaveIcon from "@material-ui/icons/Save";
import classNames from "classnames";

class SuperPitchTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showDetail: false,
      showDialog: false,
      currentPitchId: "",
      currentStatus: "",
      details: {},
      pitchInfo: {}
    };
    this.handleDetailClick = this.handleDetailClick.bind(this);
  }

  handleChangeShowDetailDialog = () => {
    this.setState({
      showDetail: !this.state.showDetail
    });
  };
  handleDetailClick = moreInfo => {
    this.setState({
      showDetail: !this.state.showDetail,
      details: moreInfo.details,
      title: moreInfo.title
    });
  };

  handleEditChange = (pitchId, d, pitchInfo) => {
    this.handleChangeShowEditDialog();
    this.setState({
      currentPitchId: pitchId,
      currentStatus: d[6],
      pitchInfo: pitchInfo
    });
  };
  handleChangeShowEditDialog = () => {
    this.setState({
      showDialog: !this.state.showDialog
    });
  };

  render() {
    // push actions button to the data array
    const { classes } = this.props;
    const { showDetail, showDialog } = this.state;

    const data = this.props.data;
    const more = this.props.more;
    const dataForCSV = this.props.dataForCSV;
    const headersForCSV = this.props.headersForCSV;
    data.forEach((d, index) => {

      if (d.length < 8) {
        d.push(
          <Button
            justIcon
            round
            color="primary"
            className={classes.marginRight}
            onClick={() => this.handleDetailClick(more[index])}
          >
            <MoreHoriz className={classes.icons} />
          </Button>
        );
        d.push(
          [{ color: "success", icon: Edit }].map((prop, key) => {
            return (
              <Button
                round
                color={prop.color}
                className={
                  classes.actionButton + " " + classes.actionButtonRound
                }
                key={key}
                onClick={() =>
                  this.handleEditChange(
                    more[index].pitch_id,
                    d,
                    this.props.pitches[index]
                  )
                }
              >
                <prop.icon className={classes.icon} />
              </Button>
            );
          })
        );
      }
    });

    // define pitch board name according to the uri

    const current_path = this.props.path;
    let board_name = "";
    switch (current_path) {
      case "/super-admin/pitch":
        board_name = "Global Pitch Board";
        break;
      case "/super-admin/calendar":
        board_name = "Publish Calender Table";
        break;
      case "/super-admin/parking":
        board_name = "Parking Table";
        break;
      default:
        break;
    }

    return (
      <div>
        <GridContainer>
          <GridItem xs={12} sm={12} md={12}>
            <Card>
              <CardHeader color="rose" icon>
                <CardIcon color="rose">
                  <Assignment />
                </CardIcon>
                <div className={classes.right}>
                  <CSVLink
                    filename="Pitch Table"
                    data={dataForCSV}
                    headers={headersForCSV}
                  >
                    <SaveButton
                      variant="contained"
                      size="small"
                      className={classes.button}
                    >
                      <SaveIcon
                        className={classNames(
                          classes.leftIcon,
                          classes.iconSmall
                        )}
                      />
                      Save
                    </SaveButton>
                  </CSVLink>
                </div>
                <h4 className={classes.cardIconTitle}>{board_name}</h4>
              </CardHeader>
              <CardBody>
                <Table
                  tableHead={[
                    "Pitch ID",
                    "Title",
                    "Vertical",
                    "Creator ID",
                    "Created Time",
                    "Updated Time",
                    "Status",
                    "Detail",
                    "Actions"
                  ]}
                  striped
                  tableData={data}
                  customCellClasses={[
                    classes.center,
                    classes.right,
                    classes.right
                  ]}
                  customClassesForCells={[0, 4, 5, 6, 7, 8, 9]}
                  customHeadCellClasses={[
                    classes.center,
                    classes.right,
                    classes.right
                  ]}
                  customHeadClassesForCells={[0, 4, 5, 6, 7, 8, 9]}
                />
              </CardBody>
            </Card>
          </GridItem>
        </GridContainer>
        <EditDialog
          handleChangeShowEditDialog={this.handleChangeShowEditDialog}
          showDialog={showDialog}
          maxWidth="xs"
          pitchId={this.state.currentPitchId}
          updatePitchesById={this.props.updatePitchesById}
          path={this.props.path}
          data={this.state.data}
          pitchInfo={this.state.pitchInfo}
        />
        <DetailDialog
          showDialog={showDetail}
          handleChangeShowDetailDialog={this.handleChangeShowDetailDialog}
          details={this.state.details}
          title={this.state.title}
        />
      </div>
    );
  }
}

export default withStyles(extendedTablesStyle)(SuperPitchTable);
