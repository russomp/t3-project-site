import React from "react";
// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
// core components
import FormatAlignLeft from "@material-ui/icons/FormatAlignLeft";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import SuperPitchTable from "./SuperPitchTable";
import AdminPitchTable from "./AdminPitchTable";
import WriterPitchTable from "./WriterPitchTable";
import Button from "components/CustomButtons/Button.jsx";

const style = {
  typo: {
    paddingLeft: "25%",
    marginBottom: "40px",
    position: "relative"
  },
  note: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    bottom: "10px",
    color: "#c0c1c2",
    display: "block",
    fontWeight: "400",
    fontSize: "13px",
    lineHeight: "13px",
    left: "0",
    marginLeft: "20px",
    position: "absolute",
    width: "260px"
  },
  cardCategoryWhite: {
    color: "rgba(255,255,255,.62)",
    margin: "0",
    fontSize: "14px",
    marginTop: "0",
    marginBottom: "0"
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none"
  },
  headerIcon: {
    width: "16px",
    height: "16px",
    marginRight: "10px"
  },
  pitchBoardContainer: {
    position: "relative",
    marginTop: "100px"
  }
};
const SUPER_TABLE = 2;
const ADMIN_TABLE = 1;
const WRITER_TABLE = 0;
class PitchBoard extends React.Component {
  UNSAFE_componentWillMount() {
    const current_path = this.props.location.pathname;
    const userInfo = JSON.parse(localStorage.getItem("userInfo"));
    if (current_path === "/super-admin/calendar") {
      const filter = JSON.stringify({
        status: "approved"
      });
      this.props.loadPitchesByFilters(filter);
    } else if (current_path === "/super-admin/parking") {
      const filter = JSON.stringify({
        status: "parked"
      });
      this.props.loadPitchesByFilters(filter);
    } else if (current_path === "/content-contributor/dashboard") {
      const filter = JSON.stringify({
        creator_id: userInfo.username
      });
      this.props.loadPitchesByFilters(filter);
    } else {
      // Global Pitch Board
      const filter = JSON.stringify({
        status: "new"
      });
      this.props.loadPitchesByFilters(filter);
    }
  }
  getStatusButton = status => {
    const statusConfig = {
      new: {
        label: "NEW",
        color: "danger"
      },
      parked: {
        label: "PARKED",
        color: "warning"
      },
      approved: {
        label: "APPROVED",
        color: "success"
      },
      rejected: {
          label: "REJECTED",
          color: "danger"
      }
    };
    const thisStatus = statusConfig[status];
    return <Button color={thisStatus.color}>{thisStatus.label}</Button>;
  };
  render() {
    const current_path = this.props.location.pathname;
    const tables = [WriterPitchTable, AdminPitchTable, SuperPitchTable];
    let tableIndex = 0;
    switch (current_path) {
      case "/super-admin/parking":
        tableIndex = SUPER_TABLE;
        break;
      case "/super-admin/calendar":
        tableIndex = SUPER_TABLE;
        break;
      case "/super-admin/pitch":
        tableIndex = SUPER_TABLE;
        break;
      case "/content-admin/pitch":
        tableIndex = ADMIN_TABLE;
        break;
      case "/content-contributor/pitch":
        tableIndex = WRITER_TABLE;
        break;
      case "/content-contributor/dashboard":
        tableIndex = WRITER_TABLE;
        break;
      default:
    }
    const TableType = tables[tableIndex];

    const pitches = this.props.pitches.data;
    const data = pitches.map((pitch, key) => {
      return [
        key + 1,
        pitch.title,
        pitch.vertical,
        pitch.creator_id,
        pitch.created_at.substring(0, 10),
        pitch.updated_at.substring(0, 10),
        this.getStatusButton(pitch.status)
      ];
    });

    const more = pitches.map(pitch => {
      const reviewers = pitch.reviewers;
      let reviewer = null;
      console.log(reviewers);
      if (reviewers && reviewers.length === 1) {
        reviewer = reviewers[0].admin_id;
      }
      return {
        details: pitch.details,
        pitch_id: pitch.id,
        title: pitch.title,
        reviewer
      };
    });

    const dataForCSV = pitches.map((pitch, key) => {
      return [
        key + 1,
        pitch.title,
        pitch.vertical,
        pitch.creator_id,
        pitch.created_at.substring(0, 10),
        pitch.updated_at.substring(0, 10),
        pitch.status,
        pitch.details.network,
        pitch.details.url,
        pitch.details.target_info,
        pitch.details.inspiration,
        pitch.details.quiz_type,
        pitch.details.description
      ];
    });
    const headersForCSV = [
      "Pitch ID",
      "Title",
      "Vertical",
      "Creator ID",
      "Created Time",
      "Updated Time",
      "Status",
      "Buy-side network",
      "URL",
      "Target info",
      "Inspiration",
      "Quiz type",
      "Description"
    ];

    const { classes } = this.props;
    return (
      <Card className={classes.pitchBoardContainer}>
        <CardHeader color="info">
          <h4 className={classes.cardTitleWhite}>
            <FormatAlignLeft className={classes.headerIcon} />
            Pitch Table
          </h4>
          <p className={classes.cardCategoryWhite}>
            Information on vertical in this week
          </p>
        </CardHeader>
        <CardBody>
          <TableType
            path={this.props.location.pathname}
            data={data}
            dataForCSV={dataForCSV}
            headersForCSV={headersForCSV}
            more={more}
            reviewPitches={this.props.reviewPitches}
            updatePitchesById={this.props.updatePitchesById}
            pitches={pitches} // For edit use
          />
        </CardBody>
      </Card>
    );
  }
}

export default withStyles(style)(PitchBoard);
