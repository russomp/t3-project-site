import React from "react";
// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
// core components
import CardBody from "components/Card/CardBody.jsx";
import { successColor } from "assets/jss/material-dashboard-pro-react.jsx";
import green from "@material-ui/core/colors/green";
import Dialog from "@material-ui/core/es/Dialog/Dialog";
import Button from "../../components/CustomButtons/Button";
import TextField from "@material-ui/core/es/TextField/TextField";
import Info from "@material-ui/icons/Info";
import NavPills from "../../components/NavPills/NavPills";
import GridItem from "../../components/Grid/GridItem";

const style = theme => ({
  typo: {
    paddingLeft: "25%",
    marginBottom: "40px",
    position: "relative"
  },
  note: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    bottom: "10px",
    color: "#c0c1c2",
    display: "block",
    fontWeight: "400",
    fontSize: "13px",
    lineHeight: "13px",
    left: "0",
    marginLeft: "20px",
    position: "absolute",
    width: "260px"
  },
  cardCategoryWhite: {
    color: "rgba(255,255,255,.62)",
    margin: "0",
    fontSize: "14px",
    marginTop: "0",
    marginBottom: "0"
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none"
  },
  headerIcon: {
    width: "16px",
    height: "16px",
    marginRight: "10px"
  },
  pitchBoardContainer: {
    position: "relative",
    marginTop: "100px"
  },
  tagIcon: {
    backgroundColor: successColor,
    "&:hover": {
      backgroundColor: green[700]
    }
  },
  headerContainer: {
    display: "flex",
    justifyContent: "space-between"
  },
  week: {
    paddingBottom: "10px",
    borderBottom: "1px solid #4caf50"
  },
  addBtn: {
    marginTop: "45px"
  },
  assignee: {
    marginTop: "27px"
  },
  float: {
    "@media (min-width: 992px)": {
      float: "right"
    }
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200
  }
});

class EditDialog extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      showDialog: true,
      status: "",
      vertical: "",
      currentPitchId: "",
      creator_id: "",
      title: "",
      pitchInfo: {
        title: "",
        status: "new",
        details: {
          url: "",
          description: "",
          network: "",
          quiz_type: "",
          inspiration: "",
          target_info: ""
        }
      }
    };
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.pitchInfo !== this.props.pitchInfo) {
      const { title, status, details } = nextProps.pitchInfo;
      const pitchInfo = { title, status, details };
      this.setState({ pitchInfo: pitchInfo });
    }
  }

  handleDetailInputChange = name => event => {
    const { pitchInfo } = this.state;
    pitchInfo.details[name] = event.target.value;
    this.setState({
      pitchInfo: pitchInfo
    });
  };

  handleInputChange = name => event => {
    const { pitchInfo } = this.state;
    pitchInfo[name] = event.target.value;
    this.setState({
      pitchInfo: pitchInfo
    });
  };

  handleSubmit = () => {
    this.props.handleChangeShowEditDialog();
    const body = this.state.pitchInfo;
    this.props.updatePitchesById(
      JSON.stringify(body),
      this.props.pitchId,
      this.props.path
    );
  };

  handleCancel = () => {
    this.props.handleChangeShowEditDialog();
  };

  render() {
    const statusSelections = [
      {
        label: "Reject",
        value: "rejected"
      },
      {
        label: "Park",
        value: "parked"
      },
      {
        label: "Approve",
        value: "approved"
      }
    ];
    const { classes } = this.props;
    const showDialog = this.props.showDialog;
    return (
      <div>
        <Dialog open={showDialog}>
          <NavPills
            color="success"
            alignCenter
            tabs={[
              {
                tabButton: "Edit",
                tabIcon: Info,
                tabContent: (
                  <CardBody>
                    <GridItem xs={12} sm={12} md={12}>
                      <form>
                        <TextField
                          id="title"
                          label="Title"
                          fullWidth
                          className={classes.textField}
                          value={this.state.pitchInfo.title}
                          onChange={this.handleInputChange("title")}
                        />

                        <TextField
                          id="standard-select-currency-native"
                          select
                          label="Status select"
                          className={classes.textField}
                          value={this.state.pitchInfo.status}
                          onChange={this.handleInputChange("status")}
                          SelectProps={{
                            native: true,
                            MenuProps: {
                              className: classes.menu
                            }
                          }}
                        >
                          <option disabled key="new" value="new">
                            New
                          </option>
                          {statusSelections.map(option => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </TextField>

                        <TextField
                          id="network"
                          label="Buy-side network"
                          className={classes.textField}
                          value={this.state.pitchInfo.details.network}
                          onChange={this.handleDetailInputChange("network")}
                          margin="normal"
                        />

                        <TextField
                          id="url"
                          label="URL"
                          className={classes.textField}
                          value={this.state.pitchInfo.details.url}
                          onChange={this.handleDetailInputChange("url")}
                          margin="normal"
                        />

                        <TextField
                          id="quiz_type"
                          label="Quiz Type"
                          className={classes.textField}
                          value={this.state.pitchInfo.details.quiz_type}
                          onChange={this.handleDetailInputChange("quiz_type")}
                          margin="normal"
                        />

                        <TextField
                          id="target_info"
                          label="Target Info"
                          className={classes.textField}
                          value={this.state.pitchInfo.details.target_info}
                          onChange={this.handleDetailInputChange("target_info")}
                          margin="normal"
                        />

                        <TextField
                          id="inspiration"
                          label="Inspiration"
                          value={this.state.pitchInfo.details.inspiration}
                          onChange={this.handleDetailInputChange("inspiration")}
                          margin="normal"
                          multiline
                          fullWidth
                          rowsMax="5"
                        />
                        <TextField
                          id="description"
                          label="Description"
                          value={this.state.pitchInfo.details.description}
                          onChange={this.handleDetailInputChange("description")}
                          margin="normal"
                          multiline
                          fullWidth
                          rowsMax="5"
                        />

                        <Button onClick={this.handleSubmit} color="rose">
                          Submit
                        </Button>
                        <Button onClick={this.handleCancel} color="rose">
                          Cancel
                        </Button>
                      </form>
                    </GridItem>
                  </CardBody>
                )
              }
            ]}
          />
        </Dialog>
      </div>
    );
  }
}

export default withStyles(style)(EditDialog);
