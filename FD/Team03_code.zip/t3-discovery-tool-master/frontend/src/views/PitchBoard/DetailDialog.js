import React from "react";

// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";

// material-ui icons
import Info from "@material-ui/icons/Info";

// core components
import CardBody from "components/Card/CardBody.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import Dialog from "components/Dialog";
import Card from "components/Card/Card.jsx";
import NavPills from "components/NavPills/NavPills.jsx";

import extendedTablesStyle from "assets/jss/material-dashboard-pro-react/views/extendedTablesStyle.jsx";

class DetailDialog extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showDetail: false,
      showDialog: false,
      currentPitchId: "",
      currentStatus: "",

      details: {}
    };
  }

  render() {
    // push actions button to the data array
    const { classes } = this.props;
    const showDialog = this.props.showDialog;
    return (
      <Dialog
        open={showDialog}
        cancel={this.props.handleChangeShowDetailDialog}
      >
        <NavPills
          color="warning"
          alignCenter
          tabs={[
            {
              tabButton: "Detail",
              tabIcon: Info,
              tabContent: (
                <Card>
                  <CardHeader>
                    <h4 className={classes.cardTitle}>
                      Title: {this.props.title}
                    </h4>
                  </CardHeader>
                  <div>
                    <b>Quiz Type :</b>
                    {this.props.details.quiz_type}
                  </div>
                  <div>
                    <b>Url:</b> {this.props.details.description}
                  </div>

                  <div>
                    <b>Inspiration:</b>
                    {this.props.details.inspiration}
                  </div>

                  <div>
                    <b>Suggested Buy-side Network :</b>
                    {this.props.details.network}
                  </div>

                  <div>
                    <b>Targeting Info:</b>
                    {this.props.details.target_info}
                  </div>
                  <div>
                    <b>Description:</b> {this.props.details.description}
                  </div>

                  <CardBody />
                </Card>
              )
            }
          ]}
        />
      </Dialog>
    );
  }
}

export default withStyles(extendedTablesStyle)(DetailDialog);
