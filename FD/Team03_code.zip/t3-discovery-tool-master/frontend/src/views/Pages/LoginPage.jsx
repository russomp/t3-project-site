import React from 'react';
import PropTypes from 'prop-types';
import 'antd/dist/antd.css';

// import redux store
// import { connect } from 'react-redux';

// @material-ui/core components
import withStyles from '@material-ui/core/styles/withStyles';
import InputAdornment from '@material-ui/core/InputAdornment';
import Icon from '@material-ui/core/Icon';

// @material-ui/icons
import Face from '@material-ui/icons/Face';
// import LockOutline from "@material-ui/icons/LockOutline";

// core components
import GridContainer from 'components/Grid/GridContainer.jsx';
import GridItem from 'components/Grid/GridItem.jsx';
import CustomInput from 'components/CustomInput/CustomInput.jsx';
import Button from 'components/CustomButtons/Button.jsx';
import Card from 'components/Card/Card.jsx';
import CardBody from 'components/Card/CardBody.jsx';
import CardHeader from 'components/Card/CardHeader.jsx';
import CardFooter from 'components/Card/CardFooter.jsx';
import { message } from 'antd';


import loginPageStyle from 'assets/jss/material-dashboard-pro-react/views/loginPageStyle.jsx';

// const mapStateToProps = state => {
//   return {
//     isPending: state.isPending,
//     isAuthenticated: state.isAuthenticated,
//     error: state.error,
//   };
// };
//
// const mapDispatchToProps = dispatch => {
//   return {
//     onLoginUser: (username, pswd) => dispatch(loginUser(username, pswd)),
//   };
// };

class LoginPage extends React.Component {
  constructor(props) {
    super(props);
    // we use this to make the card to appear after the page has been rendered
    this.state = {
      cardAnimaton: 'cardHidden',
      username: '',
      password: '',
      alert: true,
    };
  }
  componentDidMount() {
    // we add a hidden class to the card and after 700 ms we delete it and the transition appears
    this.timeOutFunction = setTimeout(
      function() {
        this.setState({ cardAnimaton: '' });
      }.bind(this),
      700
    );
    if (this.props.location.state) {
      const msg = this.props.location.state.message;
      if (msg) {
        message.error(msg);
      }
    }
  }

  handleClickLogin = () => {
    const body = {
      username: this.state.username,
      password: this.state.password,
    };
    this.props.login(JSON.stringify(body));
    this.setState({ alert: true });
  };
  componentWillUnmount() {
    clearTimeout(this.timeOutFunction);
    this.timeOutFunction = null;
  }
  handleInputChange = name => event => {
    this.setState({ [name]: event.target.value });
  };

  render() {
    const { classes } = this.props;
    return (
      <div className={classes.container}>
        <GridContainer justify="center">
          <GridItem xs={12} sm={6} md={4}>
            <form>
              <Card login className={classes[this.state.cardAnimaton]}>
                <CardHeader
                  className={`${classes.cardHeader} ${classes.textCenter}`}
                  color="info"
                >
                  <h4 className={classes.cardTitle}>Log in</h4>
                </CardHeader>
                <CardBody>
                  <CustomInput
                    labelText="Username"
                    id="firstname"
                    formControlProps={{
                      fullWidth: true,
                    }}
                    inputProps={{
                      onChange: this.handleInputChange('username'),
                      type: 'text',
                      endAdornment: (
                        <InputAdornment position="end">
                          <Face className={classes.inputAdornmentIcon} />
                        </InputAdornment>
                      ),
                    }}
                    onChange={e => this.setState({ username: e.target.value })}
                    value={this.state.username}
                  />
                  <CustomInput
                    labelText="Password"
                    id="password"
                    formControlProps={{
                      fullWidth: true,
                    }}
                    inputProps={{
                      onChange: this.handleInputChange('password'),
                      type: 'password',
                      endAdornment: (
                        <InputAdornment position="end">
                          <Icon className={classes.inputAdornmentIcon}>
                            lock_outline
                          </Icon>
                        </InputAdornment>
                      ),
                    }}
                    onChange={e => this.setState({ password: e.target.value })}
                  />
                  {this.props.loginInfo.isFail
                    ? 'Incorrect passowrd or username'
                    : null}
                </CardBody>
                <CardFooter className={classes.justifyContentCenter}>
                  <Button
                    color="rose"
                    simple
                    size="lg"
                    onClick={this.handleClickLogin}
                    block
                  >
                    Log in
                  </Button>
                </CardFooter>
                {this.props.isPending && <div>Please wait...</div>}
                {this.props.isAuthenticated && <div>Success.</div>}
                {this.props.error && <div>{this.props.error}</div>}
              </Card>
            </form>
          </GridItem>
        </GridContainer>
      </div>
    );
  }
}

LoginPage.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(loginPageStyle)(LoginPage);
