
import React, {Component} from 'react';
// import {PropTypes} from 'prop-types';
import 'antd/dist/antd.css';
import moment from 'moment';

import Card from "components/Card/Card.jsx";
import CardBody from "components/Card/CardBody.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Table from "components/Table/Table.jsx";
import Button from "components/CustomButtons/Button.jsx";
import SnackbarContent from "components/Snackbar/SnackbarContent.jsx";

import { DatePicker, Select, Progress, Modal, Input, InputNumber, List } from 'antd';
import { Button as AntdButton}  from 'antd';
import { DemoData, verticals } from './data.js';
import { loadGoal, createGoal } from 'actions/goals/load-goals-by-filters';

const { WeekPicker } = DatePicker;
const Option = Select.Option;
const InputGroup = Input.Group;


function createGoalEntry(verticals) {
    let ret = {}
    Object.keys(verticals).forEach(v => {
        ret[v] = 0;
    })
    return ret;
}

// function createDefaultVerticals(newVerticals, oldVerticals) {
//     Object.keys(newVerticals).forEach(key => {
//         if (!key in oldVerticals) {
//             oldVerticals[key] = 0
//         }
//     })
//     return oldVerticals;
// }

function loadGoalVerticals (data) {
    const verticals = data.data.verticals;
    const total_number = data.data.total_number;
    let ret = {}

    verticals.forEach((v, index) => {
        ret[v] = total_number[index]
    })
    return ret;
}

class Calander extends Component{
    constructor(props){
        super(props);
        this.state = {
            showEdit: false,
            chosenVertical: verticals[0],
            verticals: {
                'Game': 0,
                'Sport': 0,
                'Entertainment': 0,
                'University': 0,
                'Education': 0
             },
            weekChosen: moment(new Date(), 'YYYY-Do'),
            goal: null,
            backendAlert: null,
            newGoal: {
                'deadline': moment(new Date(), 'YYYY-Do'),
                'verticals': createGoalEntry(verticals)
            }
        }
        this.handleSelectWeek = this.handleSelectWeek.bind(this);
        this.verticalStat = this.verticalStat.bind(this);
        this.handleSelectVerical = this.handleSelectVerical.bind(this);
        this.oneVerticalStat = this.oneVerticalStat.bind(this);
        this.addNewVertical = this.addNewVertical.bind(this);
        this.InputGroup = this.InputGroup.bind(this);
        this.handleInputNumChange = this.handleInputNumChange.bind(this);
        this.handleInputChange = this.handleInputChange.bind(this);
        this.boardLoadGoal = this.boardLoadGoal.bind(this);
        this.deleteInput = this.deleteInput.bind(this);
        this.submitNewGoal = this.submitNewGoal.bind(this);

    }

    componentDidMount() {
        this.boardLoadGoal();
    }

    boardLoadGoal() {
        const weekChosen = this.state.weekChosen;
        const body = {
            "deadline": weekChosen.year() + "-" + weekChosen.week()
        }

        loadGoal(JSON.stringify(body))
        .then(data => {
            if (data.success) {
                this.setState({
                    goal: data.data,
                    verticals: loadGoalVerticals(data),
                    chosenVertical: data.data.verticals[0]
                })
            } else {
                this.setState({
                    goal: null,
                    backendAlert: data.message
                })
            }
        })
        .catch(err => {
            console.log(err);
        })
    }

    handleSelectWeek(date, dateString) {
        this.setState({
            weekChosen: moment(date, 'YYYY-Do')
        }, () => {
            this.boardLoadGoal();
        })
    }

    handleSelectVerical(val) {
        this.setState({
            chosenVertical: val
        });
    }

    verticalStat(data) {
        let ret = [];
        data.total_number.forEach((element, index) => {
            ret.push([data.verticals[index], data.completed_number[index] + " / " + element]);
        });
        return ret
    }

    oneVerticalStat(data) {
        let ret = [];
        const stat = data.completed_stats[this.state.chosenVertical];
        const names = Object.keys(stat);
        const vals = Object.values(stat);
        names.forEach((n, index) => {
            ret.push([n, vals[index].completed_number, <Progress percent={vals[index].completed_number * 100 / vals[index].total_number} size="small" />])
        })
        return ret;
    }

    handleInputChange(key, e) {
        let { verticals } = this.state;
        if (verticals !== undefined) {
            verticals[e.target.value] = verticals[key]
            delete verticals[key]
            this.setState({verticals});
        }
    }

    handleInputNumChange(key, number) {
        let { verticals } = this.state;
        if (verticals !== undefined) {
            verticals[key] = number;
            this.setState({verticals});
        }
    }

    InputGroup() {
        if (this.state.verticals !== null) {
            return  Object.keys(this.state.verticals).map((key, index) => {
                return <List.Item>
                    <InputGroup>
                        <Input value={key} style={{ width: '40%' }} onChange={(e) => this.handleInputChange(key, e)}/>
                        <InputNumber style={{ width: '40%' }} defaultValue={this.state.verticals[key]}  onChange={(number) => this.handleInputNumChange(key, number)}/>
                        <AntdButton style={{marginLeft: '10px'}} shape="circle" icon="delete" onClick={(e) => this.deleteInput(key, e)}/>
                    </InputGroup>
                </List.Item>
            })
        }
    }

    addNewVertical() {
        let verticals = {...this.state.verticals};
        verticals['new_vertical' + Object.keys(verticals).length] = 0;
        this.setState({verticals});
    }

    deleteInput(key, e) {
        let { verticals } = this.state;
        if (verticals !== undefined) {
            delete verticals[key]
            this.setState({verticals});
        }
    }

    submitNewGoal() {
        const { weekChosen, verticals } = this.state;
        console.log(verticals)
        const body = {
            "deadline": weekChosen.year() + "-" + weekChosen.week(),
            "verticals": verticals
        }

        createGoal(JSON.stringify(body))
        .then(data => {
            console.log(data);
            this.setState({
                showEdit: !this.state.showEdit
            }, () => {
                this.boardLoadGoal()
            });
        })
        .catch(err => {
            console.log(err);
        })
    }

    render(){
        const { weekChosen, goal, verticals } = this.state;
        const tableData = goal == null ? [] : this.verticalStat(goal);
        const verticalStat = goal == null ? [] : this.oneVerticalStat(goal);
        const index = goal == null ? 0 : goal.verticals.indexOf(this.state.chosenVertical);
        const percent = goal == null ? 0 : 100 * goal.completed_number[index] / goal.total_number[index]

        return (
            <div>
                <Card>
                    <CardHeader>
                        <WeekPicker onChange={this.handleSelectWeek} placeholder="Select week" defaultValue={weekChosen}/>
                    </CardHeader>
                    <CardBody>
                        {
                            goal == null ?
                                <div style={{display: 'flex', justifyContent: 'center'}}>
                                    <SnackbarContent
                                        message={
                                            this.state.backendAlert
                                        }
                                        color="warning"
                                        place="tc"
                                    />
                                </div>
                            :
                            <div>
                                <GridContainer>
                                    <GridItem xs={12} sm={4} md={4}>
                                        <i class="fas fa-crown"></i><b> Assignor: </b>{DemoData.assignor}
                                    </GridItem>
                                    <GridItem xs={12} sm={4} md={4}>
                                        <i class="fas fa-hourglass-start"></i><b> Create Time: </b> {new Date(goal.created_time).toDateString()}
                                    </GridItem>
                                    <GridItem xs={12} sm={4} md={4}>
                                        <i class="fas fa-wrench"></i><b> Last Update: </b> {new Date(goal.updated_time).toDateString()}
                                    </GridItem>
                                </GridContainer>
                                <hr />
                                <GridContainer>
                                    <GridItem xs={12} sm={3} md={3}>
                                        <i class="fas fa-tasks"></i> verticals
                                        <Table
                                            tableHeaderColor="primary"
                                            tableData={tableData}
                                        />
                                    </GridItem>
                                    <GridItem xs={12} sm={3} md={3}>
                                        <i class="fas fa-users"></i> contributors
                                        <Table
                                            tableHeaderColor="primary"
                                            tableData={goal.contributor_list.map(c => [c])}
                                        />
                                    </GridItem>
                                    <GridItem xs={12} sm={6} md={6}>
                                        <GridContainer>
                                            <GridItem xs={12} sm={6} md={6}>
                                                <i class="fas fa-info"></i> progress
                                            </GridItem>
                                            <GridItem xs={12} sm={6} md={6}>
                                                <Select defaultValue="verticals" style={{ width: 120, top: '-10px' }} onSelect={this.handleSelectVerical}>
                                                    {
                                                        Object.keys(verticals).map(v => {
                                                            return <Option value={v}>{v}</Option>
                                                        })
                                                    }
                                                </Select>
                                            </GridItem>
                                            <GridContainer>
                                                <GridItem xs={12} sm={6} md={6}>
                                                    <Progress type="dashboard" width={230} percent={percent.toFixed(2)} />
                                                </GridItem>
                                                <GridItem xs={12} sm={6} md={6}>
                                                    <Table
                                                        tableHeaderColor="primary"
                                                        tableData={verticalStat}
                                                    />
                                                </GridItem>
                                            </GridContainer>
                                        </GridContainer>
                                    </GridItem>
                                </GridContainer>
                            </div>
                        }
                        <GridContainer justify="flex-end">
                            <GridItem xs={12} sm={12} md={7}>
                                <Button color="success" onClick={() => {this.setState({showEdit: !this.state.showEdit})}}>{goal == null ? 'Create Goal' : 'Edit'}</Button>
                            </GridItem>
                        </GridContainer>
                    </CardBody>
                </Card>
                <Modal
                    visible={this.state.showEdit} title="Create/Edit a goal"
                    onOk={this.submitNewGoal}
                    onCancel={() => {this.setState({showEdit: !this.state.showEdit})}}
                >
                    <List>
                        {this.InputGroup()}
                    </List>
                    <AntdButton type="primary" shape="circle" icon="plus" onClick={this.addNewVertical}/>
                </Modal>
            </div>
        )
    }

}

export default Calander
