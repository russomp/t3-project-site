export const DemoData = {
  _id: "121212121212121212",
  assignor: "Xizhao Deng",
  verticals: ["Game", "Sport", "Entertainment", "University", "Education"],
  year: "2018",
  week: 42,
  total_number: [200, 100, 300, 50, 40],
  completed_number: [120, 30, 150, 45, 40],
  completed_stats: {
      "Game": {
         "Yiming Zhang": 12,
         "Fan Zhang": 20,
         "Shenghao Tang": 17,
         "Jinzhou Hong": 14,
         "Guangcheng Liu": 15 
      },
      "Sport": {
        "Yiming Zhang": 12,
        "Fan Zhang": 22,
        "Shenghao Tang": 77,
        "Jinzhou Hong": 47,
        "Guangcheng Liu": 45 
     },
     "Entertainment": {
        "Yiming Zhang": 17,
        "Fan Zhang": 50,
        "Shenghao Tang": 37,
        "Jinzhou Hong": 34,
        "Guangcheng Liu": 15 
     },
     "University": {
        "Yiming Zhang": 12,
        "Fan Zhang": 60,
        "Shenghao Tang": 37,
        "Jinzhou Hong": 44,
        "Guangcheng Liu": 25 
     },
     "Education": {
        "Yiming Zhang": 12,
        "Fan Zhang": 20,
        "Shenghao Tang": 37,
        "Jinzhou Hong": 34,
        "Guangcheng Liu": 25 
     }
  },
  contributor_list: ["Yiming Zhang", "Fan Zhang", "Shenghao Tang", "Jinzhou Hong", "Guancheng Liu"],
  created_at: "2018-11-31",
  updated_at: "2018-12-5"
}

export const verticals = {
   'Game': 0,
   'Sport': 0,
   'Entertainment': 0,
   'University': 0,
   'Education': 0
}
