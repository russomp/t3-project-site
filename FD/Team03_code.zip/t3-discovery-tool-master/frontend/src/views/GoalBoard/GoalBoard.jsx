import React from "react";
// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
// core components
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import Timeline from "@material-ui/icons/Timeline";
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import { successColor } from "assets/jss/material-dashboard-pro-react.jsx";
import green from "@material-ui/core/colors/green";

import Calander from "./components/Calander.js";

const style = {
  typo: {
    paddingLeft: "25%",
    marginBottom: "40px",
    position: "relative"
  },
  note: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    bottom: "10px",
    color: "#c0c1c2",
    display: "block",
    fontWeight: "400",
    fontSize: "13px",
    lineHeight: "13px",
    left: "0",
    marginLeft: "20px",
    position: "absolute",
    width: "260px"
  },
  cardCategoryWhite: {
    color: "rgba(255,255,255,.62)",
    margin: "0",
    fontSize: "14px",
    marginTop: "0",
    marginBottom: "0"
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none"
  },
  headerIcon: {
    width: "16px",
    height: "16px",
    marginRight: "10px"
  },
  pitchBoardContainer: {
    position: "relative",
    marginTop: "100px"
  },
  tagIcon: {
    backgroundColor: successColor,
    "&:hover": {
      backgroundColor: green[700]
    }
  },
  headerContainer: {
    display: "flex",
    justifyContent: "space-between"
  },
  week: {
    paddingBottom: "10px",
    borderBottom: "1px solid #4caf50"
  },
  addBtn: {
    marginTop: "45px"
  },
  assignee: {
    marginTop: "27px"
  }
};

class GoalBoard extends React.Component {

  render() {
    const { classes } = this.props;

    return (
      <div>
        <Card className={classes.pitchBoardContainer}>
          <CardHeader color="success">
            <div className={classes.headerContainer}>
              <div>
                <h4 className={classes.cardTitleWhite}>
                  <Timeline className={classes.headerIcon} />
                  Goal Board
                </h4>
                <p className={classes.cardCategoryWhite}>
                  Display history task Goal and make a new plan
                </p>
              </div>
            </div>
          </CardHeader>
          <CardBody>
            <GridContainer>
              <GridItem xs={12} sm={12} md={12}>
                <Calander />
              </GridItem>
            </GridContainer>
          </CardBody>
        </Card>
      </div>
    );
  }
}

export default withStyles(style)(GoalBoard);
