import React from 'react';

// @material-ui/core components
import withStyles from '@material-ui/core/styles/withStyles';
// @material-ui/icons
import PermIdentity from '@material-ui/icons/PermIdentity';

// core components

import GridContainer from 'components/Grid/GridContainer.jsx';
import GridItem from 'components/Grid/GridItem.jsx';
import Button from 'components/CustomButtons/Button.jsx';
import CustomInput from 'components/CustomInput/CustomInput.jsx';
import Clearfix from 'components/Clearfix/Clearfix.jsx';
import Card from 'components/Card/Card.jsx';
import CardBody from 'components/Card/CardBody.jsx';
import CardHeader from 'components/Card/CardHeader.jsx';
import CardIcon from 'components/Card/CardIcon.jsx';
import RoleBadge from '../../components/RoleBadge/RoleBadge';

const styles = {
  cardCategoryWhite: {
    color: 'rgba(255,255,255,.62)',
    margin: '0',
    fontSize: '14px',
    marginTop: '0',
    marginBottom: '0',
  },
  cardTitleWhite: {
    color: '#FFFFFF',
    marginTop: '0px',
    minHeight: 'auto',
    fontWeight: '300',
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: '3px',
    textDecoration: 'none',
  },
};

class SettingPage extends React.Component {
  constructor(props) {
    super(props);
    const { first_name, last_name, city, state, country } = props.profile;
    this.state = {
      profile_fname: first_name ? first_name : '',
      profile_lname: last_name ? last_name : '',
      profile_city: city ? city : '',
      profile_state: state ? state : '',
      profile_country: country ? country : '',
    };
  }
  handleInputChange = name => event => {
    this.setState({ [name]: event.target.value });
  };
  handleUpdateProfile = () => {
    const { username } = this.props.currentUser;
    const updatedUserdata = {
      first_name: this.state.profile_fname,
      last_name: this.state.profile_lname,
      city: this.state.profile_city,
      state: this.state.profile_state,
      country: this.state.profile_country,
    };
    this.props.editProfile(username, updatedUserdata);
  };
  render() {
    const { classes } = this.props;
    const { username, role } = JSON.parse(localStorage.userInfo);
    const { first_name, last_name, city, state, country } = this.props.profile;
    return (
      <div style={{ overflowX: 'hidden' }}>
        <GridItem xs={12} sm={12} md={8}>
          <Card>
            <CardHeader color="rose" icon>
              <CardIcon color="rose">
                <PermIdentity />
              </CardIcon>
              <h3 className={classes.cardIconTitle}>
                {`${first_name} ${last_name} (@${username})`}
                <RoleBadge role={role} />
              </h3>
            </CardHeader>
            <CardBody>
              <GridContainer>
                <GridItem xs={12} sm={12} md={6}>
                  <CustomInput
                    labelText="First Name"
                    id="profile_fname"
                    formControlProps={{
                      fullWidth: true,
                    }}
                    inputProps={{
                      placeholder: first_name,
                      onChange: this.handleInputChange('profile_fname'),
                      value: this.state.profile_fname,
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  <CustomInput
                    labelText="Last Name"
                    id="profile-lname"
                    formControlProps={{
                      fullWidth: true,
                    }}
                    inputProps={{
                      placeholder: last_name,
                      onChange: this.handleInputChange('profile_lname'),
                      value: this.state.profile_lname,
                    }}
                  />
                </GridItem>
              </GridContainer>
              <GridContainer>
                <GridItem xs={12} sm={12} md={4}>
                  <CustomInput
                    labelText="City"
                    id="profile_city"
                    formControlProps={{
                      fullWidth: true,
                    }}
                    inputProps={{
                      placeholder: city,
                      onChange: this.handleInputChange('profile_city'),
                      value: this.state.profile_city,
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={4}>
                  <CustomInput
                    labelText="State"
                    id="profile_state"
                    formControlProps={{
                      fullWidth: true,
                    }}
                    inputProps={{
                      placeholder: state,
                      onChange: this.handleInputChange('profile_state'),
                      value: this.state.profile_state,
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={4}>
                  <CustomInput
                    labelText="Country"
                    id="profile_country"
                    formControlProps={{
                      fullWidth: true,
                    }}
                    inputProps={{
                      placeholder: country,
                      onChange: this.handleInputChange('profile_country'),
                      value: this.state.profile_country,
                    }}
                  />
                </GridItem>
              </GridContainer>
              <Button
                color="rose"
                className={classes.updateProfileButton}
                onClick={this.handleUpdateProfile}
              >
                Update Profile
              </Button>
              <Clearfix />
            </CardBody>
          </Card>
        </GridItem>
        {/* <GridItem xs={12} sm={12} md={4}>
          <Card profile>
            <CardAvatar profile>
              <a href="#pablo" onClick={e => e.preventDefault()}>
                <img src={avatar} alt="..." />
              </a>
            </CardAvatar>
            <CardBody profile>
              <h6 className={classes.cardCategory}>CEO / CO-FOUNDER</h6>
              <h4 className={classes.cardTitle}>Alec Thompson</h4>
              <p className={classes.description}>
                Don't be scared of the truth because we need to restart the
                human foundation in truth And I love you like Kanye loves Kanye
                I love Rick Owens’ bed design but the back is...
              </p>
              <Button color="rose" round>
                Follow
              </Button>
            </CardBody>
          </Card>
        </GridItem> */}
      </div>
    );
  }
}

export default withStyles(styles)(SettingPage);
