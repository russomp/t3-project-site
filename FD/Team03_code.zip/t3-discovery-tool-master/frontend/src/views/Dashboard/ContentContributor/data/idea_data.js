export const data =[
  [
    "1",
    "Idea title1",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New",
    "N/A",
    "N/A",
    "N/A"
  ],
  [
    "2",
    "Idea title2",
    "Andrew Mike",
    "2018-10-21 17:32",
    "Approved once",
    "Micheal Russo",
    "N/A",
    "N/A"
  ],
  [
    "3",
    "Idea title3",
    "Andrew Mike",
    "2018-10-21 17:32",
    "Published",
    "Micheal Russo",
    "Fan Zhang",
    "Kerry Deng"
  ],
  [
    "4",
    "Idea title4",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New",
    "N/A",
    "N/A",
    "N/A"
  ],
  [
    "5",
    "Idea title5",
    "Andrew Mike",
    "2018-10-21 17:32",
    "Approved twice",
    "Micheal Russo",
    "Fan Zhang",
    "N/A"
  ],
  [
    "6",
    "Idea title1",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New",
    "N/A",
    "N/A",
    "N/A"
  ],
  [
    "7",
    "Idea title1",
    "Andrew Mike",
    "2018-10-21 17:32",
    "Published",
    "Micheal Russo",
    "Fan Zhang",
    "Kerry Deng"
  ],
  [
    "8",
    "Idea title1",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New",
    "N/A",
    "N/A",
    "N/A"
  ],
  [
    "9",
    "Idea title1",
    "Andrew Mike",
    "2018-10-21 17:32",
    "Published",
    "Micheal Russo",
    "Fan Zhang",
    "Kerry Deng"
  ],
  [
    "10",
    "Idea title1",
    "Andrew Mike",
    "2018-10-21 17:32",
    "Published",
    "Micheal Russo",
    "Fan Zhang",
    "Kerry Deng"
  ]
]