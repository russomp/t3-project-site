import React from "react";
// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
// @material-ui/icons
import Edit from "@material-ui/icons/Edit";
// core components
import GridContainer from "components/Grid/GridContainer.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CustomLinearProgress from "components/CustomLinearProgress/CustomLinearProgress.jsx";

import chartsStyle from "assets/jss/material-dashboard-pro-react/views/chartsStyle.jsx";
import moment from "moment";
import ReactTable from "react-table";

// react plugin for creating charts

class WorkLoad extends React.Component {
  UNSAFE_componentWillMount() {
    const userInfo = JSON.parse(localStorage.getItem("userInfo"));
    const filter = JSON.stringify({
      assignee_username: userInfo["username"]
    });
    this.props.loadGoalsByFilters(filter);
  }

  render() {
    const raw_data = this.props.goals.data;
    const data = raw_data.map((goal, idx) => {
      const intDay = moment(goal.deadline, "YYYY-WW")
        .add(6, "days")
        .valueOf();
      return {
        index: idx,
        verticals: goal.verticals,
        total_number: goal.total_number,
        completed_number: goal.completed_number,
        deadline: moment(intDay).format("YYYY-MM-DD"),
        created_at: goal.created_at.substring(0, 10),

        progress: (
          <CustomLinearProgress
            variant="determinate"
            color="success"
            value={(goal.completed_number * 100.0) / goal.total_number}
            style={{ width: "65%", display: "inline-block" }}
          />
        )
      };
    });
    const { classes } = this.props;
    return (
      <div>
        <GridContainer>
          <GridItem xs={12} sm={12} md={12}>
            <Card>
              <CardHeader color="success" icon>
                <CardIcon color="success">
                  <Edit />
                </CardIcon>
                <h4 className={classes.cardIconTitle}>
                  Current Workload and progress
                </h4>
              </CardHeader>
              <CardBody>
                <GridContainer justify="space-between">
                  <GridItem xs={12} sm={12} md={12}>
                    <ReactTable
                      columns={[
                        {
                          Header: "#",
                          accessor: "index"
                        },
                        {
                          Header: "Vertical",
                          accessor: "verticals"
                        },

                        {
                          Header: "Completed #",
                          accessor: "completed_number"
                        },
                        {
                          Header: "Pitch Needed",
                          accessor: "total_number"
                        },
                        {
                          Header: "Due Date",
                          accessor: "deadline"
                        },
                        {
                          Header: "Issue Date",
                          accessor: "created_at"
                        },
                        {
                          Header: "Progress",
                          accessor: "progress"
                        }
                      ]}
                      data={data}
                    />
                  </GridItem>
                </GridContainer>
              </CardBody>
            </Card>
          </GridItem>
        </GridContainer>
      </div>
    );
  }
}

export default withStyles(chartsStyle)(WorkLoad);
