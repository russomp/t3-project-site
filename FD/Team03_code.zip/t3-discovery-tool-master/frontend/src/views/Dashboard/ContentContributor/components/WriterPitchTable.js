import React from "react";
// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
// material-ui icons
import Assignment from "@material-ui/icons/Assignment";
import Done from "@material-ui/icons/Done";
import MoreHoriz from "@material-ui/icons/MoreHoriz";
import Close from "@material-ui/icons/Close";
// core components
import SaveIcon from "@material-ui/icons/Save";

import GridContainer from "components/Grid/GridContainer.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import Table from "components/Table/Table.jsx";
import Button from "components/CustomButtons/Button.jsx";
import SaveButton from "@material-ui/core/Button";

import CardBody from "components/Card/CardBody.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import Card from "components/Card/Card.jsx";

import extendedTablesStyle from "assets/jss/material-dashboard-pro-react/views/extendedTablesStyle.jsx";
import EditDialog from "./EditDialog";
import DetailDialog from "./DetailDialog";
import { CSVLink } from "react-csv";
import IconButton from "@material-ui/core/es/IconButton/IconButton";
import classNames from "classnames";
const styles = theme => ({
  button: {
    margin: theme.spacing.unit
  },
  leftIcon: {
    marginRight: theme.spacing.unit
  },
  rightIcon: {
    marginLeft: theme.spacing.unit
  },
  iconSmall: {
    fontSize: 20
  }
});
class PublishedPitchTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showDetail: false,
      showDialog: false,
      currentPitchId: "",
      currentStatus: "",

      details: {}
    };
    this.handleDetailClick = this.handleDetailClick.bind(this);
  }

  handleChangeShowDetailDialog = () => {
    console.log(this.state.showDetail);
    this.setState({
      showDetail: !this.state.showDetail
    });
  };
  handleDetailClick = moreInfo => {
    this.setState({
      showDetail: !this.state.showDetail,
      details: moreInfo.details,
      title: moreInfo.title
    });
  };
  handleEditChange = (pitchId, d) => {
    this.handleChangeShowEditDialog();
    this.setState({
      currentPitchId: pitchId,
      currentStatus: d[6]
    });
  };
  handleChangeShowEditDialog = () => {
    this.setState({
      showDialog: !this.state.showDialog
    });
  };
  getColor = (more, index, userInfo, color) => {
    return more[index].reviewer === userInfo.username ? "default" : color;
  };

  handleReviewAction = (key, more, index, userInfo) => {
    // console.log("what is the userInfo in pitch board");
    // console.log(localStorage.getItem("userInfo"));
    // const userInfo = JSON.parse(localStorage.getItem("userInfo"));
    // console.log(userInfo.username);

    let body = {};
    if (key === 0) {
      body = {
        status: "approved",
        admin_id: userInfo.username
      };
    } else {
      body = {
        status: "rejected",
        admin_id: userInfo.username
      };
    }
    this.props.reviewPitches(JSON.stringify(body), more[index].pitch_id);
  };

  render() {
    console.log("hello world");
    const { classes } = this.props;
    const { showDetail, showDialog } = this.state;
    const data = this.props.data;
    const more = this.props.more;

    const dataForCSV = this.props.dataForCSV;
    const headersForCSV = this.props.headersForCSV;
    const userInfo = JSON.parse(localStorage.getItem("userInfo"));
    data.forEach((d, index) => {
      if (d.length <= 8) {
        d.push(
          <Button
            justIcon
            round
            color="primary"
            className={classes.marginRight}
            onClick={() => this.handleDetailClick(more[index])}
          >
            <MoreHoriz className={classes.icons} />
          </Button>
        );
        d.push(
          [
            { color: "info", icon: Done, id: "approve" },
            { color: "danger", icon: Close, id: "reject" }
          ].map((prop, key) => {
            // const superAdmin =
            //   this.props.path === "/super-admin/pitch" && prop.id === "edit";
            // const admin =
            //   this.props.path === "/content-admin/pitch" &&
            //   (prop.id === "approve" || prop.id === "reject");
            // if (superAdmin || admin) {

            return (
              <Button
                round
                color={this.getColor(more, index, userInfo, prop.color)}
                className={
                  classes.actionButton + " " + classes.actionButtonRound
                }
                key={key}
                onClick={() => {
                  switch (key) {
                    case 2:
                      return this.handleEditChange(more[index].pitch_id, d);

                    default:
                      return this.handleReviewAction(
                        key,
                        more,
                        index,
                        userInfo
                      );
                  }
                }}
              >
                <prop.icon className={classes.icon} />
              </Button>
            );
            // }
          })
        );
      }
    });



    return (
      <div>
        <GridContainer>
          <GridItem xs={12} sm={12} md={12}>
            <Card>
              <CardHeader color="rose" icon>
                <CardIcon color="rose">
                  <Assignment />
                </CardIcon>
                <div className={classes.right}>
                  <CSVLink
                    filename="Pitch Table"
                    data={dataForCSV}
                    headers={headersForCSV}
                  >
                    <SaveButton
                      variant="contained"
                      size="small"
                      className={classes.button}
                    >
                      <SaveIcon
                        className={classNames(
                          classes.leftIcon,
                          classes.iconSmall
                        )}
                      />
                      Save
                    </SaveButton>
                  </CSVLink>
                </div>

                <h4 className={classes.cardIconTitle}>Global Pitch Board</h4>
              </CardHeader>
              <CardBody>
                <Table
                  tableHead={[
                    "Pitch ID",
                    "Title",
                    "Vertical",
                    "Creator ID",
                    "Created Time",
                    "Updated Time",
                    "Status",
                    "Detail",
                    "Action"
                  ]}
                  tableData={data}
                  customCellClasses={[
                    classes.center,
                    classes.right,
                    classes.right
                  ]}
                  customClassesForCells={[0, 4, 5]}
                  customHeadCellClasses={[
                    classes.center,
                    classes.right,
                    classes.right
                  ]}
                  customHeadClassesForCells={[0, 4, 5]}
                />
              </CardBody>
            </Card>
          </GridItem>
        </GridContainer>
        <EditDialog
          handleChangeShowEditDialog={this.handleChangeShowEditDialog}
          showDialog={showDialog}
          maxWidth="xs"
          pitchId={this.state.currentPitchId}
          updatePitchesById={this.props.updatePitchesById}
          path={this.props.path}
          data={this.state.data}
        />
        <DetailDialog
          showDialog={showDetail}
          handleChangeShowDetailDialog={this.handleChangeShowDetailDialog}
          details={this.state.details}
          title={this.state.title}
        />
      </div>
    );
  }
}

export default withStyles(extendedTablesStyle)(PublishedPitchTable);
