export const data =[
  [
    "1",
    "Idea title1",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New"
  ],
  [
    "2",
    "Idea title2",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New"
  ],
  [
    "3",
    "Idea title3",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New"
  ],
  [
    "4",
    "Idea title4",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New"
  ],
  [
    "5",
    "Idea title5",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New"
  ],
  [
    "6",
    "Idea title1",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New"
  ],
  [
    "7",
    "Idea title1",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New"
  ],
  [
    "8",
    "Idea title1",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New"
  ],
  [
    "9",
    "Idea title1",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New"
  ],
  [
    "10",
    "Idea title1",
    "Andrew Mike",
    "2018-10-21 17:32",
    "New"
  ]
]