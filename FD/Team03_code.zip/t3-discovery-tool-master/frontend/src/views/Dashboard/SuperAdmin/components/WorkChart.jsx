import React from "react";
import 'antd/dist/antd.css';
// react plugin for creating charts
import ChartistGraph from "react-chartist";
import moment from 'moment';
import { loadWeekProgress, loadMemberProgress } from 'actions/work_progress/load_weekly_progress.js';

// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";

// @material-ui/icons
import Timeline from "@material-ui/icons/Timeline";

// core components
import GridContainer from "components/Grid/GridContainer.jsx";
import GridItem from "components/Grid/GridItem.jsx";

import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import CardBody from "components/Card/CardBody.jsx";
import './index.css';

import { DatePicker, Carousel, Select } from 'antd';

import {
  colouredLineChart,
  multipleBarsChart,
  personLineChart
} from "variables/charts.jsx";

import chartsStyle from "assets/jss/material-dashboard-pro-react/views/chartsStyle.jsx";

const { WeekPicker, MonthPicker } = DatePicker;
const Option = Select.Option;


class WorkChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      week: moment(new Date(), 'YYYY-Do'),
      month: moment(new Date(), 'YYYY-MM'),
      week_progress: {},
      member_progress: {},
      tab2Person: null
    }
    this.carousel = React.createRef();
    this.handleSelectWeek = this.handleSelectWeek.bind(this);
    this.checkPersonProgress = this.checkPersonProgress.bind(this);
    this.loadWorkProgress = this.loadWorkProgress.bind(this);
    this.loadMemberProgress = this.loadMemberProgress.bind(this);
    this.handleSelectMonth = this.handleSelectMonth.bind(this);
  }

  componentDidMount() {
    this.loadWorkProgress()
    this.loadMemberProgress()
  }
  loadWorkProgress() {
    const week = this.state.week;
    const curBody =  {
      date: week.year() + "-" + week.week()
    }

    const preWeek = moment(new Date(), 'YYYY-Do').subtract(7, 'd')
    const preBody = {
      date: preWeek.year() + "-" + preWeek.week()
    }

    const curWeekPromise = loadWeekProgress(JSON.stringify(curBody));
    const preWeekPromise = loadWeekProgress(JSON.stringify(preBody));
    Promise.all([curWeekPromise, preWeekPromise])
    .then(response => {
      console.log(response)
      const progress = {};
      response.forEach((data, index) => {
        if (data.success) {
          progress[data.data.date] = data.data.weekly_progress;
        }
      })
      this.setState({
        week_progress: progress
      })
    })
    .catch(err => {
      console.log(err);
    })
  }

  loadMemberProgress() {
    const month = this.state.month;
    const startMonth = month.startOf('month').weeks();
    const weeks = [startMonth, startMonth + 1, startMonth + 2, startMonth + 3].map(w => month.year() + "-" + w)
    console.log(weeks)
    let promises = weeks.map(w => {
      return loadMemberProgress(JSON.stringify({deadline: w}))
    })
    Promise.all(promises)
    .then(response => {
      const progress = {};
      console.log(response)
      response.forEach((data, index) => {
        if (data.ok) {
          progress[data.date] = data.data;
        }
      })
      console.log(progress)
      this.setState({
        member_progress: progress
      })
    })
    .catch(err => {
      console.log(err);
    })
  }

  handleSelectWeek(date, dateString) {
    this.setState({
      week: date
    }, () => {
      this.loadWorkProgress();
    })
  }

  handleSelectMonth(date, dateString) {
    this.setState({
      month: date
    }, () => {
      this.loadMemberProgress();
    })
  }

  checkPersonProgress(val) {
    console.log(val);
    this.carousel.current.goTo(1, false);
    this.setState({
      tab2Person: val
    })
  }

  render() {
    const { classes } = this.props;
    colouredLineChart.data.series = Object.values(this.state.week_progress);
    const dates = Object.keys(this.state.week_progress);

    const curWeek = this.state.week.year() + "-" + this.state.week.week();
    const wkData = this.state.member_progress[curWeek];
    const members = wkData === undefined ? [] : Object.keys(wkData);
    const datas = wkData === undefined ? [] : Object.values(wkData);
    multipleBarsChart.data.labels = members.sort();
    multipleBarsChart.data.series[0] = datas.map(d => d.total_number);
    multipleBarsChart.data.series[1] = datas.map(d => d.completed_number);
    multipleBarsChart.data.series[2] = datas.map(d => d.approved_number);


    const weeks = Object.keys(this.state.member_progress).sort();
    personLineChart.data.series = [
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ]
    weeks.forEach((w, index) => {
      const data = this.state.member_progress[w][this.state.tab2Person];
      personLineChart.data.series[0][index] = data !== undefined ? data.total_number : 0;
      personLineChart.data.series[1][index] = data !== undefined ? data.completed_number: 0;
      personLineChart.data.series[2][index] = data !== undefined ? data.approved_number: 0;
    })

    return (
      <div>
        <GridContainer>
          <GridItem xs={12} sm={12} md={6}>
            <Card>
              <CardHeader>
                <GridContainer>
                  <GridItem xs={12} sm={12} md={8}>
                    <CardIcon color="info">
                      <Timeline style={{color: '#fff'}}/>
                    </CardIcon>
                    <h4 className={classes.cardIconTitle}>
                      Weekly Goal KPI <small>- finished idea</small>
                    </h4>
                  </GridItem>
                  <GridItem xs={12} sm={12} md={4}>
                    <div style={{paddingTop: "10px"}}>
                      <WeekPicker onChange={this.handleSelectWeek} placeholder="Select week" value={this.state.week}/>
                    </div>
                  </GridItem>
                </GridContainer>
              </CardHeader>
              <CardBody>
                <ChartistGraph
                  data={colouredLineChart.data}
                  type="Line"
                  options={colouredLineChart.options}
                  listener={colouredLineChart.animation}
                />
                <hr />
                {
                  dates.map((date, index) => (
                    <span><i className={"fas fa-circle " + (index === 0 ? classes.info : classes.danger)} /> {date}</span>
                  ))
                }
              </CardBody>
            </Card>
          </GridItem>
          <GridItem xs={12} sm={12} md={6}>
            <Card>
              <CardHeader>
                <GridContainer>
                  <GridItem xs={12} sm={12} md={9}>
                    <CardIcon color="rose">
                      <Timeline style={{color: '#fff'}}/>
                    </CardIcon>
                    <h4 className={classes.cardIconTitle}>
                      Work progress <small>- Target/Pitched/Approved</small>
                    </h4>
                  </GridItem>
                  <GridItem xs={12} sm={12} md={2}>
                    <div style={{paddingTop: "10px"}}>
                      <Select style={{ width: 120 }} onChange={this.checkPersonProgress} placeholder="select contributor">
                        {
                          multipleBarsChart.data.labels.map(name => (
                            <Option value={name}>{name}</Option>
                          ))
                        }
                      </Select>
                    </div>
                  </GridItem>
                </GridContainer>
              </CardHeader>
              <CardBody>
                <Carousel ref={this.carousel}>
                  <div>
                    <div style={{height: '350px', overflowY: 'scroll'}}>
                      <ChartistGraph
                        data={multipleBarsChart.data}
                        type="Bar"
                        options={multipleBarsChart.options}
                        listener={multipleBarsChart.animation}
                      />
                    </div>
                    <hr />
                    <i className={"fas fa-circle " + classes.warning} /> target {` `}
                    <i className={"fas fa-circle " + classes.danger} /> pitched {` `}
                    <i className={"fas fa-circle " + classes.info} /> approved
                  </div>
                  <div>
                    <MonthPicker placeholder="Select month" value={this.state.month} onChange={this.handleSelectMonth}/>
                    <ChartistGraph
                      data={personLineChart.data}
                      type="Bar"
                      options={personLineChart.options}
                      listener={personLineChart.animation}
                    />
                    <hr />
                    <i className={"fas fa-circle " + classes.warning} /> target {` `}
                    <i className={"fas fa-circle " + classes.danger} /> pitched {` `}
                    <i className={"fas fa-circle " + classes.info} /> approved
                  </div>
                </Carousel>
              </CardBody>
            </Card>
          </GridItem>
        </GridContainer>
      </div>
    );
  }
}

export default withStyles(chartsStyle)(WorkChart);
