import React from "react";
// @material-ui/core components
import MButton from "@material-ui/core/Button";
import purple from "@material-ui/core/colors/purple";
// @material-ui/icons
import AddIcon from "@material-ui/icons/Add";
import Group from "@material-ui/icons/Group";
import ReactTable from "react-table";
// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Button from "components/CustomButtons/Button.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import { primaryColor } from "assets/jss/material-dashboard-pro-react.jsx";
import Dialog from "components/Dialog";
import CustomInput from "components/CustomInput/CustomInput.jsx";
import Done from "@material-ui/icons/Done";
import Close from "@material-ui/icons/Close";
import MenuItem from "@material-ui/core/es/MenuItem/MenuItem";
import withStyles from "@material-ui/core/styles/withStyles";
import { Select } from "@material-ui/core/es/index";
import FormLabel from "@material-ui/core/es/FormLabel/FormLabel";
import FormControl from "@material-ui/core/es/FormControl/FormControl";
import DeleteIcon from "@material-ui/icons/Delete";
import IconButton from "@material-ui/core/es/IconButton/IconButton";
import swal from "sweetalert";

const styles = {
  cardCategoryWhite: {
    color: "rgba(255,255,255,.62)",
    margin: "0",
    fontSize: "14px",
    marginTop: "0",
    marginBottom: "0"
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    textDecoration: "none"
  },
  cardHeader: {
    display: "flex",
    justifyContent: "space-between"
  },
  headerIcon: {
    width: "16px",
    height: "16px",
    marginRight: "10px"
  },
  tagIcon: {
    backgroundColor: primaryColor,
    "&:hover": {
      backgroundColor: purple[700]
    }
  },
  input: {
    display: "none"
  }
};
const InitialUserInfo = {
  role: "writer",
  username: "",
  password: "",
  first_name: "",
  last_name: ""
};

class TeamMember extends React.Component {
  UNSAFE_componentWillMount() {
    this.props.loadAllUsers();
  }

  constructor(props) {
    super(props);
    this.state = {
      userInfo: {
        role: "writer",
        username: "",
        password: "",
        first_name: "",
        last_name: ""
      },
      showDialog: false,
      confirm_password: "",
      has_unfilled_items: false
    };
  }

  handleInputChange = name => event => {
    const { userInfo } = this.state;
    if (name === "confirm_password") {
      this.setState({
        confirm_password: event.target.value
      });
    }
    userInfo[name] = event.target.value;
    this.setState({
      userInfo: userInfo
    });
  };
  handleAddMember = () => {
    this.setState({
      showDialog: !this.state.showDialog,
      has_unfilled_items: false
    });
  };

  confirmAddMember = () => {
    const { userInfo } = this.state;
    for (let key in userInfo) {
      // userInfo.forEach(ele => {
      if (userInfo[key].length === 0) {
        this.setState({ has_unfilled_items: true });
        return;
      }
    }
    if (this.state.confirm_password === userInfo.password) {
      console.log("submit!");
      this.props.createUsers(JSON.stringify(userInfo));
      this.setState({ userInfo: InitialUserInfo });
    } else {
      return;
    }
    this.setState({
      showDialog: !this.state.showDialog
    });
  };

  cancelAddMember = () => {
    this.setState({
      showDialog: !this.state.showDialog
    });
  };
  handleDone = username => {
    const body = {
      is_active: false
    };
    this.props.updateUserByUsername(JSON.stringify(body), username);
  };
  handleClose = username => {
    const body = {
      is_active: true
    };
    this.props.updateUserByUsername(JSON.stringify(body), username);
  };
  handleChangeRole = username => event => {
    const body = {
      role: event.target.value
    };
    this.props.updateUserByUsername(JSON.stringify(body), username);
  };
  handleDeleteUser = (username, role) => {
    if (role === "superadmin") {
      swal(
        "The super admin cannot be deleted! Please contact admin.",
        "",
        "error"
      );
      return;
    }
    this.props.deleteUserByUsername(username);
  };

  render() {
    const { classes } = this.props;

    const allUsers = this.props.allUsers.data;
    const data = allUsers.map((user, key) => {
      return {
        id: key + 1,
        username: user.username,
        first_name: user.first_name,
        last_name: user.last_name,
        role:
          user.role === "superadmin" ? (
            <Button xs={10} color="primary">
              Super admin
            </Button>
          ) : (
            <Select
              value={user.role}
              onChange={this.handleChangeRole(user.username)}
              id="role"
              inputProps={{
                name: "role",
                id: "role"
              }}
            >
              <MenuItem
                classes={{
                  root: classes.selectMenuItem,
                  selected: classes.selectMenuItemSelected
                }}
                value="admin"
              >
                Admin
              </MenuItem>
              <MenuItem
                classes={{
                  root: classes.selectMenuItem,
                  selected: classes.selectMenuItemSelected
                }}
                value="writer"
              >
                Writer
              </MenuItem>
            </Select>
          ),
        is_active: user.is_active ? (
          <Button
            color="success"
            className={classes.marginRight}
            onClick={() => {
              this.handleDone(user.username);
            }}
          >
            <Done className={classes.icon} />
          </Button>
        ) : (
          <Button
            onClick={() => {
              this.handleClose(user.username);
            }}
            color="danger"
            className={classes.marginRight}
          >
            <Close className={classes.icon} />
          </Button>
        ),
        created_at: user.created_at.substring(0, 10),
        action: (
          <IconButton
            onClick={() => {
              this.handleDeleteUser(user.username, user.role);
            }}
            aria-label="Delete"
            className={classes.margin}
          >
            <DeleteIcon className={classes.icon} />
          </IconButton>
        )
      };
    });
    const unfilledColor = this.state.has_unfilled_items ? "red" : "black";

    return (
      <div style={{ overflowX: "hidden" }}>
        <GridContainer className={classes.teamMemberContainer}>
          <GridItem xs={12} sm={12} md={12}>
            <Card>
              <CardHeader color="primary" className={classes.cardHeader}>
                <div>
                  <h4 className={classes.cardTitleWhite}>
                    <Group className={classes.headerIcon} />
                    Team Member List
                  </h4>
                </div>
                <MButton
                  variant="fab"
                  color="secondary"
                  aria-label="Add"
                  className={classes.tagIcon}
                  onClick={this.handleAddMember}
                >
                  <AddIcon />
                </MButton>
              </CardHeader>
              <CardBody>
                <ReactTable
                  data={data}
                  filterable
                  columns={[
                    {
                      Header: "#",
                      accessor: "id"
                    },
                    {
                      Header: "Username",
                      accessor: "username"
                    },
                    {
                      Header: "First Name",
                      accessor: "first_name"
                    },
                    {
                      Header: "Last Name",
                      accessor: "last_name"
                    },
                    {
                      Header: "Role",
                      accessor: "role"
                    },
                    {
                      Header: "Active status",
                      accessor: "is_active"
                    },
                    {
                      Header: "Enrolled Date",
                      accessor: "created_at"
                    },
                    {
                      Header: "",
                      accessor: "action"
                    }
                  ]}
                />
              </CardBody>
            </Card>
          </GridItem>
        </GridContainer>
        <Dialog
          open={this.state.showDialog}
          confirm={this.confirmAddMember}
          cancel={this.cancelAddMember}
        >
          <Card>
            <CardHeader color="primary">
              <h4>New Member</h4>
            </CardHeader>
            <CardBody>
              <form>
                <GridItem>
                  <div
                    style={{ color: unfilledColor }}
                    className={classes.labelHorizontal}
                  >
                    <small>*</small>
                    Required fields
                  </div>
                </GridItem>

                <CustomInput
                  success={this.state.registerNameState === "success"}
                  error={this.state.registerNameState === "error"}
                  labelText="Username *"
                  id="username"
                  formControlProps={{
                    fullWidth: true
                  }}
                  inputProps={{
                    onChange: this.handleInputChange("username"),
                    type: "username"
                  }}
                />
                {/*<CustomInput*/}
                {/*success={this.state.registerEmailState === "success"}*/}
                {/*error={this.state.registerEmailState === "error"}*/}
                {/*labelText="Email Address *"*/}
                {/*id="registeremail"*/}
                {/*formControlProps={{*/}
                {/*fullWidth: true*/}
                {/*}}*/}
                {/*inputProps={{*/}
                {/*onChange: event =>*/}
                {/*this.change(event, "registerEmail", "email"),*/}
                {/*type: "email"*/}
                {/*}}*/}
                {/*/>*/}

                <CustomInput
                  success={this.state.registerPasswordState === "success"}
                  error={this.state.registerPasswordState === "error"}
                  labelText="Password *"
                  id="password"
                  formControlProps={{
                    fullWidth: true
                  }}
                  inputProps={{
                    onChange: this.handleInputChange("password"),
                    type: "password"
                  }}
                />
                <CustomInput
                  success={
                    this.state.registerConfirmPasswordState === "success"
                  }
                  error={this.state.registerConfirmPasswordState === "error"}
                  labelText="Confirm Password *"
                  id="confirm_password"
                  formControlProps={{
                    fullWidth: true
                  }}
                  inputProps={{
                    onChange: this.handleInputChange("confirm_password"),
                    type: "password"
                  }}
                />
                {this.state.confirm_password ===
                this.state.userInfo.password ? null : (
                  <GridItem>
                    <div
                      style={{ color: "red" }}
                      className={classes.labelHorizontal}
                    >
                      The passwords you entered do not match. !
                    </div>
                  </GridItem>
                )}

                <GridContainer>
                  <GridItem xs={3}>
                    <FormLabel className={classes.labelHorizontal}>
                      Role
                    </FormLabel>
                  </GridItem>

                  <GridItem xs={12}>
                    <FormControl
                      fullWidth
                      className={classes.selectFormControl}
                    >
                      <Select
                        value={this.state.userInfo.role}
                        onChange={this.handleInputChange("role")}
                        id="role"
                        inputProps={{
                          name: "role",
                          id: "role"
                        }}
                      >
                        <MenuItem
                          classes={{
                            root: classes.selectMenuItem,
                            selected: classes.selectMenuItemSelected
                          }}
                          value="admin"
                        >
                          Admin
                        </MenuItem>
                        <MenuItem
                          classes={{
                            root: classes.selectMenuItem,
                            selected: classes.selectMenuItemSelected
                          }}
                          value="writer"
                        >
                          Writer
                        </MenuItem>
                      </Select>
                    </FormControl>
                  </GridItem>
                </GridContainer>
                <CustomInput
                  success={this.state.registerPasswordState === "success"}
                  error={this.state.registerPasswordState === "error"}
                  labelText="First Name *"
                  id="first_name"
                  formControlProps={{
                    fullWidth: true
                  }}
                  inputProps={{
                    onChange: this.handleInputChange("first_name"),
                    type: "text"
                  }}
                />

                <CustomInput
                  success={this.state.registerPasswordState === "success"}
                  error={this.state.registerPasswordState === "error"}
                  labelText="Last name *"
                  id="last_name"
                  formControlProps={{
                    fullWidth: true
                  }}
                  inputProps={{
                    onChange: this.handleInputChange("last_name"),
                    type: "text"
                  }}
                />
              </form>
            </CardBody>
          </Card>
        </Dialog>
      </div>
    );
  }
}

export default withStyles(styles)(TeamMember);
