import React from "react";
import { Router, Route, Switch, Redirect } from "react-router-dom";

import indexRoutes from "routes/index.jsx";

import "assets/scss/material-dashboard-pro-react.css?v=1.4.0";
import history from "./utils/history.js";

// const mapStateToProps = state => ({
//   initValue: state.initValue
// });

Date.prototype.getWeek = function() {
  var date = new Date(this.getTime());
  date.setHours(0, 0, 0, 0);

  date.setDate(date.getDate() + 3 - ((date.getDay() + 6) % 7));

  var week1 = new Date(date.getFullYear(), 0, 4);
  return (
    1 +
    Math.round(
      ((date.getTime() - week1.getTime()) / 86400000 -
        3 +
        ((week1.getDay() + 6) % 7)) /
        7
    )
  );
};

function isLegal(path) {
  const user = JSON.parse(window.localStorage.getItem("userInfo"));
  console.log(user);
  if (path.indexOf("super-admin") > -1) {
    return user.role.indexOf("superadmin") > -1;
  } else if (path.indexOf("content-contributor") > -1) {
    return user.role.indexOf("writer") > -1;
  } else if (path.indexOf("content-admin") > -1) {
    return user.role.indexOf("admin") > -1;
  }
  return false;
}

class App extends React.Component {


  render() {
    return (
      <Router history={history}>
        <Switch>
          {indexRoutes.map((item, index) => {
            return (
              <Route
                key={index}
                path={item.path}
                render={props =>
                  !item.auth ? (
                    <item.component {...props} />
                  ) : isLegal(item.path) ? (
                    <item.component {...props} />
                  ) : (
                    <Redirect
                      to={{
                        pathname: "/login",
                        state: {
                          from: props.location,
                          message: "You are not authorized to this page."
                        }
                      }}
                    />
                  )
                }
              />
            );
          })}
        </Switch>
      </Router>
    );
  }
}

export default App;
